@echo off
rem ============================================================
rem INFINITY Phase D v6: boot installed Windows WITH the RT build
rem (runtime hooks ENABLED). This is the deep test.
rem
rem v6 changes vs v5:
rem   - memory.efi v6 RT has full serial-port diagnostics. Every
rem     milestone now prints a line starting with [INF] into
rem     serial-phase-d.log. Nothing can silently fail anymore.
rem   - After the desktop loads, ALSO run trigger-test.ps1 inside
rem     Windows (see README-FA.md) - it forces Windows to call our
rem     hooked UEFI services and proves the full chain.
rem
rem IMPORTANT: use the SAME acceleration mode number that your
rem Windows install finished with (same rule as phase-c).
rem
rem Requires: Windows already installed via phase-b.bat
rem Usage:   phase-d.bat [1 or 2 or 3]
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found.
  echo Install QEMU from: https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)

if not exist disk\win10.qcow2 (
  echo [ERROR] disk\win10.qcow2 not found.
  echo Run phase-b.bat first to install Windows into the VM.
  pause
  exit /b 1
)

if not exist vars mkdir vars
if not exist vars\OVMF_VARS_4M.fd copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul

set MODE=%~1
if "%MODE%"=="1" goto mode_ok
if "%MODE%"=="2" goto mode_ok
if "%MODE%"=="3" goto mode_ok
set MODE=
echo [Phase D] Acceleration: use the SAME mode number that your
echo [Phase D] Windows install finished with successfully.
echo   [1] WHPX fast - 2 cores
echo   [2] WHPX safe - 1 core
echo   [3] TCG - software emulation, slow boot
choice /c 123 /m "[Phase D] Choose 1, 2 or 3"
if errorlevel 3 (set MODE=3) else if errorlevel 2 (set MODE=2) else (set MODE=1)
:mode_ok

echo.
echo [Phase D] Windows + memory.efi v6 RT boot test. Mode %MODE% selected.
echo [Phase D] The banner must say: Build: v6 RT - runtime hooks ENABLED.
echo [Phase D] Watch for these milestone lines in serial-phase-d.log:
echo [Phase D]   [INF][EBS] ExitBootServices hook FIRED   (stage 2)
echo [Phase D]   [INF][VA]  SetVirtualAddressMap ... FIRED (stage 3)
echo [Phase D]   [INF][HOOK] G/S/T call#1                 (stage 4)
echo [Phase D] After the desktop loads do NOT close the window yet:
echo [Phase D]   1. inside Windows open PowerShell as Administrator
echo [Phase D]   2. run the trigger-test.ps1 script (copy it in via
echo [Phase D]      the shared folder or type its path)
echo [Phase D]   3. shutdown Windows from inside the VM
echo [Phase D]   4. then run phase-b-check.bat
echo [Phase D] If Windows hangs, resets or BSODs, that IS a valuable
echo [Phase D] result - keep the serial log and send it.
echo.

if "%MODE%"=="3" goto run_tcg

rem ---------------- WHPX mode 1 or 2 ----------------
if "%MODE%"=="1" set SMP=2
if "%MODE%"=="2" set SMP=1
"%QEMU%" -machine q35 -m 4096 -smp %SMP% -cpu host -accel whpx ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-d,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-d.log
set RC=%errorlevel%
if "%RC%"=="0" goto done
echo.
echo [Phase D] WHPX could not start, exit code %RC% - retrying with TCG.
echo.

:run_tcg
"%QEMU%" -machine q35 -m 4096 -smp 2 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-d,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-d.log

:done
echo.
echo [Phase D] Done. Next steps:
echo   1. run phase-b-check.bat and send a photo of the INFDIAG line
echo   2. send serial-phase-d.log (contains the [INF] diagnostic lines)
echo   3. send the output of trigger-test.ps1 if you ran it
echo   4. tell me which mode number you used
pause
