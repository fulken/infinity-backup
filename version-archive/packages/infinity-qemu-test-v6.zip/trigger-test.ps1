# ============================================================
# INFINITY bridge trigger test  (run INSIDE the Windows VM,
# in an ELEVATED PowerShell: "Run as Administrator")
#
# What it does:
#   1. Enables the SeSystemEnvironmentPrivilege privilege.
#   2. Calls the Windows API GetFirmwareEnvironmentVariableW to read
#      the INFDIAG variable (GUID A1B2C3D4-E5F6-4789-9ABC-DEF012345678).
#   3. Reads it twice: the first call goes THROUGH our hooked
#      GetVariable (if the v6 RT driver is active), which upgrades
#      INFDIAG to stage 4. The second read then shows the updated
#      value - if stage changed between the two reads, our hook ran
#      INSIDE Windows and chained back to the real firmware service.
#      That is the full production chain, proven.
#
# Expected results:
#   - "STAGE=4" on the second read            -> FULL CHAIN ALIVE
#   - "STAGE=2" (no change between reads)     -> hook not called
#     (Windows did not route the call through gRT, or driver absent)
#   - Error 1314                              -> PowerShell not elevated
# ============================================================

$ErrorActionPreference = 'Continue'

$src = @'
using System;
using System.Runtime.InteropServices;

public static class EfiVarBridge {
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern IntPtr GetFirmwareEnvironmentVariableW(
        string lpName, string lpGuid, byte[] pBuffer, uint nSize);

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool OpenProcessToken(
        IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool LookupPrivilegeValueW(
        string lpSystemName, string lpName, ref long lpLuid);

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES {
        public int PrivilegeCount;
        public long Luid;
        public int Attributes;
    }

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool AdjustTokenPrivileges(
        IntPtr TokenHandle, bool DisableAllPrivileges,
        ref TOKEN_PRIVILEGES NewState, int BufferLength,
        IntPtr PreviousState, IntPtr ReturnLength);
}
'@

Add-Type -TypeDefinition $src -Language CSharp

function Enable-Privilege {
    $tok = [IntPtr]::Zero
    if (-not [EfiVarBridge]::OpenProcessToken([EfiVarBridge]::GetCurrentProcess(), 0x28, [ref]$tok)) {
        Write-Host "[ERROR] OpenProcessToken failed: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
        return $false
    }
    $luid = [long]0
    if (-not [EfiVarBridge]::LookupPrivilegeValueW($null, 'SeSystemEnvironmentPrivilege', [ref]$luid)) {
        Write-Host "[ERROR] LookupPrivilegeValue failed: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
        return $false
    }
    $tp = New-Object EfiVarBridge+TOKEN_PRIVILEGES
    $tp.PrivilegeCount = 1
    $tp.Luid = $luid
    $tp.Attributes = 2  # SE_PRIVILEGE_ENABLED
    [void][EfiVarBridge]::AdjustTokenPrivileges($tok, $false, [ref]$tp, 0, [IntPtr]::Zero, [IntPtr]::Zero)
    $err = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    if ($err -eq 1300) {
        Write-Host "[ERROR] SeSystemEnvironmentPrivilege not held - run PowerShell as Administrator."
        return $false
    }
    return $true
}

function Read-Infdiag {
    param([string]$Label)
    $buf = New-Object byte[] 64
    $name = 'INFDIAG'
    $guid = '{A1B2C3D4-E5F6-4789-9ABC-DEF012345678}'
    $ret = [EfiVarBridge]::GetFirmwareEnvironmentVariableW($name, $guid, $buf, [uint32]$buf.Length)
    $err = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    if ($ret -eq [IntPtr]::Zero) {
        Write-Host "[$Label] GetFirmwareEnvironmentVariable failed, Win32Error=$err"
        switch ($err) {
            1314 { Write-Host "[$Label]   -> privilege not held (not elevated?)" }
            2    { Write-Host "[$Label]   -> variable not found (driver never loaded this boot?)" }
            87   { Write-Host "[$Label]   -> invalid parameter" }
            default { Write-Host "[$Label]   -> unexpected error code" }
        }
        return $null
    }
    $n = [int]$ret
    $hex = ($buf[0..($n-1)] | ForEach-Object { $_.ToString('X2') }) -join ' '
    Write-Host "[$Label] INFDIAG ($n bytes): $hex"
    if ($n -ge 8 -and $buf[0] -eq 0x44 -and $buf[1] -eq 0x46 -and $buf[2] -eq 0x4E -and $buf[3] -eq 0x49) {
        $stage    = $buf[4]  -bor ($buf[5]  -shl 8) -bor ($buf[6]  -shl 16) -bor ($buf[7]  -shl 24)
        $flags    = $buf[8]  -bor ($buf[9]  -shl 8) -bor ($buf[10] -shl 16) -bor ($buf[11] -shl 24)
        $build    = $buf[12] -bor ($buf[13] -shl 8) -bor ($buf[14] -shl 16) -bor ($buf[15] -shl 24)
        $cr3 = 0
        for ($i = 23; $i -ge 16; $i--) { $cr3 = ($cr3 -shl 8) -bor $buf[$i] }
        $calls    = $buf[24] -bor ($buf[25] -shl 8) -bor ($buf[26] -shl 16) -bor ($buf[27] -shl 24)
        $lastst   = $buf[28] -bor ($buf[29] -shl 8) -bor ($buf[30] -shl 16) -bor ($buf[31] -shl 24)
        Write-Host ("[$Label] STAGE={0}  flags=0x{1:X}  win_build={2}  os_cr3=0x{3:X}  hook_calls={4}  last_status=0x{5:X}" -f $stage, $flags, $build, $cr3, $calls, $lastst)
        return $stage
    }
    Write-Host "[$Label] (magic bytes do not match INFDIAG - unexpected data)"
    return $null
}

Write-Host '=== INFINITY trigger test v6 ==='
if (-not (Enable-Privilege)) { exit 1 }
Write-Host 'privilege enabled, calling the firmware variable API...'
$s1 = Read-Infdiag 'READ1'
Start-Sleep -Milliseconds 400
$s2 = Read-Infdiag 'READ2'
Write-Host ''
if ($null -eq $s2) {
    Write-Host 'RESULT: API call failed - see errors above.'
} elseif ($s1 -ne $null -and $s2 -ne $null -and $s1 -ne $s2) {
    Write-Host "RESULT: stage changed between reads ($s1 -> $s2): OUR HOOK RAN INSIDE WINDOWS. FULL CHAIN ALIVE."
} elseif ($s2 -ge 4) {
    Write-Host 'RESULT: stage 4 - a hooked service was already called. FULL CHAIN ALIVE.'
} elseif ($s2 -eq 3) {
    Write-Host 'RESULT: stage 3 - hooks installed but Windows did not call one through gRT.'
} elseif ($s2 -eq 2) {
    Write-Host 'RESULT: stage 2 - EBS hook worked; gRT hooks not called / not installed.'
} elseif ($s2 -eq 1) {
    Write-Host 'RESULT: stage 1 only - EBS never fired this boot (check serial log).'
} else {
    Write-Host "RESULT: unexpected stage $s2 - send this output plus serial-phase-d.log."
}
