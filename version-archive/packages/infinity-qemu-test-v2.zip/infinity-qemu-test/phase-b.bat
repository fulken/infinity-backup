@echo off
rem ============================================================
rem INFINITY Phase B v2: install Windows 10 into the test VM.
rem
rem v1 had 3 design bugs (my fault, fixed in v2):
rem   1. the USB ritual hijacked the boot and its startup.nsh
rem      used a hardcoded FS0: mapping that shifted when the
rem      Windows CD was attached  ->  "File not found"
rem   2. startup.nsh never launched the Windows bootloader
rem   3. there was no real hard disk and -no-reboot blocked
rem      the installer's own reboots
rem
rem v2 = clean install (no driver, no USB ritual):
rem   - creates a 64GB virtual disk  (disk\win10.qcow2)
rem   - Windows installer boots from your ISO
rem   - the VM reboots itself 2-3 times, that is normal
rem   - NVRAM (vars\) is kept between runs
rem   - tries WHPX acceleration first, falls back to TCG
rem
rem Usage:  phase-b.bat "C:\path\to\Win10.iso"
rem (or drag the ISO file onto this .bat)
rem ============================================================
setlocal
cd /d "%~dp0"
set ISO=%~1
if "%ISO%"=="" (
  echo [ERROR] Give me the Windows 10 x64 ISO path:
  echo    phase-b.bat "C:\Users\you\Downloads\Win10.iso"
  echo or drag the ISO file onto this .bat
  pause
  exit /b 1
)
if not exist "%ISO%" (
  echo [ERROR] ISO not found: %ISO%
  echo If the path has Persian characters, rename the ISO to win10.iso
  echo put it next to this file and drag it from there.
  pause
  exit /b 1
)

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found. Install QEMU from:
  echo https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)
for %%d in ("%QEMU%") do set QDIR=%%~dpd

if not exist vars mkdir vars
if not exist vars\OVMF_VARS_4M.fd copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul

if not exist disk mkdir disk
if not exist disk\win10.qcow2 (
  echo [Setup] Creating 64GB virtual disk - one time only, a few seconds...
  "%QDIR%qemu-img.exe" create -f qcow2 disk\win10.qcow2 64G
)

echo.
echo [Phase B] Installing Windows into the VM.
echo [Phase B] 1. A black QEMU window opens, wait 10-30 seconds.
echo [Phase B] 2. When it says "Press any key to boot from CD or DVD"
echo [Phase B]    PRESS A KEY FAST, otherwise setup will not start.
echo [Phase B] 3. The VM reboots itself 2-3 times during install: normal.
echo [Phase B]    Do not close the window while it installs.
echo [Phase B] 4. After the Windows desktop appears you can close it.
echo [Phase B] Trying WHPX acceleration first...
echo.

"%QEMU%" -machine q35 -m 4096 -smp 4 -cpu max -accel whpx ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=0 ^
 -drive if=none,file="%ISO%",format=raw,media=cdrom,id=winiso ^
 -device ide-cd,drive=winiso,bus=ide.1,bootindex=1 ^
 -netdev user,id=net0 -device e1000e,netdev=net0 ^
 -usb -device usb-tablet ^
 -serial file:serial-phase-b.log

if not errorlevel 1 goto done
echo.
echo [Phase B] WHPX not available - retrying with TCG emulation.
echo [Phase B] TCG is SLOW: the install can take 2-5 HOURS.
echo [Phase B] See README-FA.md to enable WHPX for a fast install.
echo.
"%QEMU%" -machine q35 -m 4096 -smp 4 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=0 ^
 -drive if=none,file="%ISO%",format=raw,media=cdrom,id=winiso ^
 -device ide-cd,drive=winiso,bus=ide.1,bootindex=1 ^
 -netdev user,id=net0 -device e1000e,netdev=net0 ^
 -usb -device usb-tablet ^
 -serial file:serial-phase-b.log

:done
echo.
echo [Phase B] Done. serial-phase-b.log was saved in this folder.
echo [Phase B] If Windows reached its desktop, next step: phase-c.bat
pause
