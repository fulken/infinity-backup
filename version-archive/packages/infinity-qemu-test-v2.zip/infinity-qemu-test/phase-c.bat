@echo off
rem ============================================================
rem INFINITY Phase C: boot the installed Windows WITH the
rem memory.efi driver loaded. This is the real test.
rem
rem Flow: USB ritual boots the EFI Shell -> startup.nsh loads
rem memory.efi -> finds the Windows Boot Manager on the virtual
rem disk -> launches it -> Windows boots with the driver resident
rem (ExitBootServices hook + CR3 capture + build detection all
rem fire during this boot).
rem
rem The whole flow was validated in the QEMU/OVMF sandbox.
rem Requires: Windows already installed via phase-b.bat
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found.
  echo Install QEMU from: https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)

if not exist disk\win10.qcow2 (
  echo [ERROR] disk\win10.qcow2 not found.
  echo Run phase-b.bat first to install Windows into the VM.
  pause
  exit /b 1
)

if not exist vars mkdir vars
if not exist vars\OVMF_VARS_4M.fd copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul

echo [Phase C] Windows + memory.efi boot test.
echo [Phase C] Flow: blue INFINITY banner -^> "Booting Windows from FSx"
echo [Phase C] -^> Windows boots with the driver resident.
echo [Phase C] If Windows hangs or reboots during boot, that IS the
echo [Phase C] test result we need - do not worry, just send the log.
echo [Phase C] Close the window once the desktop is up.
echo.

"%QEMU%" -machine q35 -m 4096 -smp 4 -cpu max -accel whpx ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-c,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -netdev user,id=net0 -device e1000e,netdev=net0 ^
 -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-c.log

if not errorlevel 1 goto done
echo.
echo [Phase C] WHPX not available - retrying with TCG emulation.
echo [Phase C] TCG boot is slow, be patient.
echo.
"%QEMU%" -machine q35 -m 4096 -smp 4 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-c,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -netdev user,id=net0 -device e1000e,netdev=net0 ^
 -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-c.log

:done
echo.
echo [Phase C] Done. Now run phase-b-check.bat, then send me:
echo   1. a photo of the INFDIAG variable on screen
echo   2. the serial-phase-c.log file
pause
