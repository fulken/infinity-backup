@echo off
rem ============================================================
rem INFINITY Phase B test: load memory.efi, then boot a Windows
rem ISO (WinPE chain: ExitBootServices + CR3 capture + build
rem detection happen when the Windows installer kernel loads).
rem
rem Usage:  phase-b.bat "C:\path\to\Win10.iso"
rem (or drag the ISO file onto this .bat)
rem ============================================================
setlocal
cd /d "%~dp0"
set ISO=%~1
if "%ISO%"=="" (
  echo [ERROR] Give me the Windows 10 ISO path:
  echo    phase-b.bat "C:\Users\you\Downloads\Win10_22H2_English_x64.iso"
  pause
  exit /b 1
)
if not exist "%ISO%" (
  echo [ERROR] ISO not found: %ISO%
  pause
  exit /b 1
)

set QEMU=
where qemu-system-x86_64.exe >nul 2>&1 && set QEMU=qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found. Install QEMU from:
  echo https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)

if not exist vars mkdir vars
copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul

echo [Phase B] Starting QEMU with Windows ISO (TCG - be patient, 3-10 min).
echo [Phase B] Flow: EFI Shell -^> module loads (blue banner) -^> Windows setup screen.
echo [Phase B] Reaching the Windows setup screen = EBS hook chain survived.
echo [Phase B] Close the QEMU window when the setup screen appears.

"%QEMU%" -machine q35 -m 4096 -accel tcg ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb,format=raw,id=usbdrv ^
 -device ide-hd,drive=usbdrv,bootindex=0 ^
 -drive if=none,file="%ISO%",format=raw,media=cdrom,id=winiso ^
 -device ide-cd,drive=winiso,bus=ide.1,bootindex=1 ^
 -net none -no-reboot -serial file:serial-phase-b.log

echo.
echo [Phase B] Done. Now run phase-b-check.bat to read the result.
pause
