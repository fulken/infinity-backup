@echo off
rem ============================================================
rem INFINITY Phase B result check: boot the check disk and dump
rem the INFDIAG variable with dmpstore.
rem Run this AFTER phase-b.bat (uses the same vars file).
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
where qemu-system-x86_64.exe >nul 2>&1 && set QEMU=qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] QEMU not found.
  pause
  exit /b 1
)

echo [Check] Booting result disk. The screen will show the INFDIAG
echo [Check] variable data. Look for the hex bytes after the GUID:
echo [Check]   44 46 4E 49 = magic, next 4 bytes = stage
echo [Check]   01 00 00 00 = stage 1 (module loaded, EBS hook chain OK)
echo [Check]   03 00 00 00 = stage 3 (runtime hook called - full chain)

"%QEMU%" -machine q35 -m 2048 -accel tcg ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-check,format=raw,id=chkdrv ^
 -device ide-hd,drive=chkdrv,bootindex=0 ^
 -net none -no-reboot -serial file:serial-check.log

pause
