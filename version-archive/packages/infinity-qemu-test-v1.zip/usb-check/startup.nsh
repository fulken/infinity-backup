echo === INFINITY result check ===
echo === INFDIAG stage: 1=module loaded, 3=runtime-hook called ===
dmpstore INFDIAG*
echo === end ===
