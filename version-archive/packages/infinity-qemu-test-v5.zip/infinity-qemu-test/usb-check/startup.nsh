echo === INFINITY result check (v5) ===
echo === INFDIAG lives under the driver vendor GUID.
echo === dmpstore without -guid searches only the global GUID
echo === and always says "No matching variables found".
echo ===
echo === STAGES (v5):
echo ===  1 = driver loaded OK (pool + handler + EBS hook installed)
echo ===  2 = ExitBootServices FIRED - CR3 + Windows build captured
echo ===  3 = RT build: gRT hooks installed at SetVirtualAddressMap
echo ===  4 = RT build: WINDOWS CALLED a hooked service - full chain
echo ===
echo === SAFE build expectation after a real Windows boot: stage 2
echo ===      (os_cr3 nonzero, win_build 19045, flags 1)
echo === RT build expectation after a full boot: stage 4
echo ===
echo === If several INFDIAG lines appear, the LAST one is current.
dmpstore INFDIAG* -guid A1B2C3D4-E5F6-4789-9ABC-DEF012345678
echo === end ===
