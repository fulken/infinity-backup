@echo off
rem ============================================================
rem INFINITY Phase D v5: boot the installed Windows with the RT
rem (runtime hooks) driver. THE REAL TEST of the whole chain.
rem
rem What is different from phase-c.bat:
rem   - default driver = memory-rt.efi (RT build): installs gRT
rem     hooks (GetTime / GetVariable / SetVariable) at the
rem     SetVirtualAddressMap event, BEFORE ExitBootServices on
rem     Windows. After Windows boots, the request handler becomes
rem     callable BY the OS through those hooks.
rem   - option 2 = SAFE build (same as phase-c) for comparison.
rem
rem What we learn from INFDIAG (read it afterwards with
rem phase-b-check.bat):
rem   stage 1  = driver loaded
rem   stage 2  = ExitBootServices fired, CR3 + build captured
rem   stage 3  = hooks installed at SetVirtualAddressMap
rem   stage 4  = WINDOWS CALLED a hooked service = FULL CHAIN
rem
rem IMPORTANT:
rem   - use the SAME acceleration mode number that your Windows
rem     install finished with (TCG = 3 for most people).
rem   - if Windows hangs or restarts: THAT IS A RESULT. Note the
rem     last thing you saw, close the window, run phase-b-check.bat
rem     and send everything. A hang right after the INFINITY banner
rem     with stage 3 recorded tells us exactly where to dig next.
rem
rem Requires: Windows already installed (phase-b.bat), QEMU.
rem Usage:   phase-d.bat [driver] [accel]
rem           driver: 1=RT (default)  2=SAFE
rem           accel : 1=WHPX2 2=WHPX1 3=TCG
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found.
  echo Install QEMU from: https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)

if not exist disk\win10.qcow2 (
  echo [ERROR] disk\win10.qcow2 not found.
  echo Run phase-b.bat first to install Windows into the VM.
  pause
  exit /b 1
)

if not exist usb-rt\memory.efi (
  echo [ERROR] usb-rt\memory.efi not found.
  pause
  exit /b 1
)

rem ---------------- driver choice ----------------
set DRV=%~1
if "%DRV%"=="1" goto drv_ok
if "%DRV%"=="2" goto drv_ok
set DRV=
echo [Phase D] Driver build:
echo   [1] RT   - runtime hooks ENABLED  (the real phase-D test)
echo   [2] SAFE - no runtime hooks       (control / comparison)
choice /c 12 /m "[Phase D] Choose driver 1=RT 2=SAFE"
if errorlevel 2 (set DRV=2) else (set DRV=1)
:drv_ok

set RITUAL=usb-rt
if "%DRV%"=="2" set RITUAL=usb-c

rem ---------------- acceleration mode ----------------
set MODE=%~2
if "%MODE%"=="1" goto mode_ok
if "%MODE%"=="2" goto mode_ok
if "%MODE%"=="3" goto mode_ok
set MODE=
echo [Phase D] Acceleration: use the SAME mode number your Windows
echo [Phase D] install finished with successfully.
echo   [1] WHPX fast - 2 cores
echo   [2] WHPX safe - 1 core
echo   [3] TCG - software emulation, slow boot
choice /c 123 /m "[Phase D] Choose 1, 2 or 3"
if errorlevel 3 (set MODE=3) else if errorlevel 2 (set MODE=2) else (set MODE=1)
:mode_ok

echo.
if "%DRV%"=="1" (
  echo [Phase D] Driver: RT build - runtime hooks ENABLED.
  echo [Phase D] Banner will say: "Build: RT - runtime hooks ENABLED"
) else (
  echo [Phase D] Driver: SAFE build - control run.
  echo [Phase D] Banner will say: "Build: SAFE - no runtime hooks"
)
echo [Phase D] Acceleration mode %MODE%. Ritual FAT: %RITUAL%
echo.
echo [Phase D] Watch for: blue INFINITY banner -^> driver loads -^>
echo [Phase D] Windows boots. With the RT build, the first Windows
echo [Phase D] boot after the driver is the moment of truth:
echo [Phase D]   - desktop reached          = likely stage 4 WIN
echo [Phase D]   - hang / restart / BSOD    = read INFDIAG after
echo [Phase D] Do not worry about a hang - it is data, not damage.
echo.

if "%MODE%"=="3" goto run_tcg

rem ---------------- WHPX mode 1 or 2 ----------------
if "%MODE%"=="1" set SMP=2
if "%MODE%"=="2" set SMP=1
"%QEMU%" -machine q35 -m 4096 -smp %SMP% -cpu host -accel whpx ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:%RITUAL%,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-d.log
set RC=%errorlevel%
if "%RC%"=="0" goto done
echo.
echo [Phase D] WHPX could not start, exit code %RC% - retrying with TCG.
echo.

:run_tcg
"%QEMU%" -machine q35 -m 4096 -smp 2 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:%RITUAL%,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-d.log

:done
echo.
echo [Phase D] Done. Now run phase-b-check.bat and send me:
echo   1. photo of the INFDIAG variable on screen
echo   2. the serial-phase-d.log file
echo   3. driver used (RT/SAFE) + mode number
echo   4. how far Windows got (desktop / hang / BSOD / reset)
pause
