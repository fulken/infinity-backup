@echo off
rem ============================================================
rem INFINITY result check v2: boot the check disk and dump the
rem INFDIAG variable with dmpstore + the correct vendor GUID.
rem
rem v1 bug (user found it): "dmpstore INFDIAG*" without -guid
rem searches only the EFI global-variable GUID and always prints
rem "No matching variables found". The driver writes INFDIAG
rem under its own vendor GUID:
rem   A1B2C3D4-E5F6-4789-9ABC-DEF012345678
rem The startup.nsh now passes -guid, matching the manual command
rem that already worked on the real bench.
rem
rem Stage semantics (v5 builds):
rem   01 = driver loaded OK (pool + handler + EBS hook installed).
rem   02 = ExitBootServices FIRED: CR3 + Windows build captured.
rem        EXPECTED result after a full Windows boot with the SAFE
rem        build (phase-c) - os_cr3 nonzero + win_build 19045.
rem   03 = RT build: gRT hooks installed at SetVirtualAddressMap.
rem   04 = RT build: WINDOWS CALLED a hooked service = FULL CHAIN.
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
where qemu-system-x86_64.exe >nul 2>&1 && set QEMU=qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] QEMU not found.
  pause
  exit /b 1
)

echo [Check] Booting result disk. The screen will show the INFDIAG
echo [Check] variable data. Look for the hex bytes after the GUID:
echo [Check]   44 46 4E 49 = magic INFD
echo [Check]   02 00 00 00 = stage 2 = EBS FIRED (SAFE build green)
echo [Check]   03 00 00 00 = stage 3 = RT hooks installed
echo [Check]   04 00 00 00 = stage 4 = OS CALLED A HOOK (FULL WIN)
echo [Check] Several lines may appear - the LAST one is current.

"%QEMU%" -machine q35 -m 2048 -accel tcg ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-check,format=raw,id=chkdrv ^
 -device ide-hd,drive=chkdrv,bootindex=0 ^
 -nic none -no-reboot -serial file:serial-check.log

pause
