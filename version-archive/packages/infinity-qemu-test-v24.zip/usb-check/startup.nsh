echo === INFINITY result check (v6) ===
echo === INFDIAG lives under the driver vendor GUID below.
echo === Plain dmpstore searches only the global GUID and
echo === always says No matching variables found.
echo ===
echo === STAGES:
echo ===  1 driver loaded OK, pool and handler and EBS hook installed
echo ===  2 ExitBootServices FIRED, os_cr3 and win_build captured
echo ===  3 RT build, gRT hooks installed at SetVirtualAddressMap
echo ===  4 RT build, WINDOWS CALLED a hooked service, full chain
echo ===
echo === After a full boot to desktop the expectation is:
echo ===  SAFE build: stage 2.  RT build: stage 2 or 4.
echo ===  RT build stuck at stage 3 with cr3 zero: the EBS write
echo ===  failed, the serial log has the exact error.
echo ===
echo === 32 bytes = magic DFNI, stage, flags, win_build, os_cr3,
echo === hook_calls, last_status. If several lines appear, the
echo === LAST one is current.
dmpstore INFDIAG* -guid A1B2C3D4-E5F6-4789-9ABC-DEF012345678
echo === end ===
