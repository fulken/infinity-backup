# ============================================================
# INFINITY refresh-files v1 (package v9)
# Push files into the RUNNING VM - NO VM restart needed.
#
# How it works: phase-d.bat v9+ starts QEMU with a control
# port (monitor) open on 127.0.0.1:5555. This script tells
# QEMU to unplug the old transfer stick and plug in a NEW
# virtual USB stick that mirrors the CURRENT contents of the
# "transfer" folder on your machine. A few seconds later the
# stick appears inside Windows in the VM (a new Removable
# drive, e.g. E: or F:) with your files on it.
#
# Usage:
#   1. Copy any file you want inside the VM into the
#      "transfer" folder (next to this script).
#   2. Double-click refresh-files.bat (or run this .ps1).
#   3. In the VM: open Explorer - a new Removable drive
#      appeared. Copy your files off it. Done.
#   4. Repeat as often as you like - the VM stays running.
#
# Copying files OUT of the VM: put them on the stick inside
# Windows (E:), then run this script again. The old stick is
# unplugged and its contents are written back into the same
# "transfer" folder, then a fresh stick appears.
#
# Rules (the script enforces these itself):
#   - no disk images (*.qcow2, *.vhd, *.vhdx, *.vmdk,
#     *.iso, *.wim, *.img, *.raw) - virtual FAT drives
#     corrupt silently when they get too full
#   - keep the folder under 400 MB
# ============================================================

param(
    [string]$Folder = '',
    [int]$Port = 5555
)

$ErrorActionPreference = 'Stop'

Write-Host ''
Write-Host '=== INFINITY refresh-files (package v9) - live file transfer ==='
Write-Host '=== push files into the RUNNING VM - no restart needed        ==='
Write-Host ''

# ---------------- folder checks ----------------
if (-not $Folder) { $Folder = Join-Path $PSScriptRoot 'transfer' }

if (-not (Test-Path -LiteralPath $Folder)) {
    New-Item -ItemType Directory -Path $Folder -Force | Out-Null
    Write-Host "[refresh] Created the transfer folder:"
    Write-Host "[refresh]   $Folder"
    Write-Host "[refresh] Drop your files into it, then run this script again."
    exit 0
}
$Folder = (Resolve-Path -LiteralPath $Folder).ProviderPath

$files = @(Get-ChildItem -LiteralPath $Folder -Recurse -File)
$bad = @($files | Where-Object { $_.Extension -match '^\.(qcow2|vhd|vhdx|vmdk|iso|wim|img|raw|vdi|dmg)$' })
if ($bad.Count -gt 0) {
    Write-Host '[refresh] ERROR: disk-image files are not allowed in the transfer folder:'
    foreach ($f in $bad) { Write-Host ("[refresh]    " + $f.FullName) }
    Write-Host '[refresh] A QEMU virtual FAT drive is small; disk images break it and every'
    Write-Host '[refresh] file on it gets silently corrupted. Move only small files.'
    exit 1
}
$sum = ($files | Measure-Object -Property Length -Sum).Sum
if (-not $sum) { $sum = 0 }
if ($sum -gt 400MB) {
    Write-Host ('[refresh] ERROR: transfer folder holds {0:N1} MB - the limit is 400 MB.' -f ($sum / 1MB))
    Write-Host '[refresh] The virtual FAT stick breaks above that. Remove files and retry.'
    exit 1
}
if ($files.Count -eq 0) {
    Write-Host '[refresh] NOTE: the transfer folder is empty - the stick will be empty.'
} else {
    Write-Host ('[refresh] Delivering {0} file(s), {1:N1} KB from:' -f $files.Count, ($sum / 1KB))
    Write-Host ("[refresh]   " + $Folder)
    $shown = 0
    foreach ($f in $files) {
        if ($shown -ge 15) { Write-Host '[refresh]   ...'; break }
        $rel = $f.FullName.Substring($Folder.Length).TrimStart('\')
        Write-Host ('[refresh]   {0}  ({1:N0} B)' -f $rel, $f.Length)
        $shown++
    }
}

# ---------------- connect to the QEMU monitor ----------------
$client = $null
try {
    $client = New-Object System.Net.Sockets.TcpClient
    $client.Connect('127.0.0.1', $Port)
} catch {
    Write-Host "[refresh] ERROR: cannot reach the QEMU control port (127.0.0.1:$Port)."
    Write-Host '[refresh] Is the VM running? It must be started with phase-d.bat from'
    Write-Host '[refresh] package v9 or newer (older packages do not open the port).'
    if ($client) { $client.Close() }
    exit 1
}
$stream = $client.GetStream()

function Read-UntilPrompt {
    param([int]$TimeoutSec = 10)
    $end = [DateTime]::UtcNow.AddSeconds($TimeoutSec)
    $sb = New-Object System.Text.StringBuilder
    while ([DateTime]::UtcNow -lt $end) {
        if ($stream.DataAvailable) {
            $b = $stream.ReadByte()
            if ($b -lt 0) { break }
            if ($b -lt 127) { [void]$sb.Append([char]$b) }   # skip telnet control bytes
            if ($sb.ToString() -match '\(qemu\)\s*$') { break }
        } else {
            Start-Sleep -Milliseconds 40
        }
    }
    return $sb.ToString()
}

function Send-Cmd {
    param([string]$Cmd, [int]$TimeoutSec = 10)
    $bytes = [System.Text.Encoding]::ASCII.GetBytes($Cmd + "`n")
    $stream.Write($bytes, 0, $bytes.Length)
    $stream.Flush()
    return Read-UntilPrompt -TimeoutSec $TimeoutSec
}

$null = Read-UntilPrompt -TimeoutSec 5     # banner + prompt

# ---------------- unplug the previous stick (ok if none) ----------------
$null = Send-Cmd -Cmd 'device_del infstick' -TimeoutSec 15
Start-Sleep -Seconds 2
$null = Send-Cmd -Cmd 'drive_del infstick0' -TimeoutSec 10
Start-Sleep -Seconds 1

# ---------------- plug in a fresh stick with current contents ----------------
$add = Send-Cmd -Cmd 'drive_add 0 if=none,id=infstick0,file=fat:rw:transfer,format=raw' -TimeoutSec 25
$dev = Send-Cmd -Cmd 'device_add usb-storage,id=infstick,drive=infstick0' -TimeoutSec 15
$info = Send-Cmd -Cmd 'info block' -TimeoutSec 10

if ($info -match 'infstick0') {
    $usb = Send-Cmd -Cmd 'info usb' -TimeoutSec 10
    Write-Host ''
    Write-Host '[refresh] OK - the stick is plugged into the running VM.'
    Write-Host '[refresh] Inside Windows, after a few seconds, a new REMOVABLE drive'
    Write-Host '[refresh] appears (E: or F:) with the files listed above.'
    if ($usb -match 'usb-storage|infstick') {
        Write-Host '[refresh] QEMU reports the USB device as active.'
    }
    $rc = 0
} else {
    Write-Host ''
    Write-Host '[refresh] ERROR: the stick did not attach. Raw monitor replies:'
    Write-Host ('    drive_add : ' + (($add -replace '\s+', ' ')).Trim())
    Write-Host ('    device_add: ' + (($dev -replace '\s+', ' ')).Trim())
    Write-Host '[refresh] Checks:'
    Write-Host '[refresh]  - the VM must have been started by phase-d.bat (package v9+) from'
    Write-Host '[refresh]    THIS folder (its working directory must be this folder)'
    Write-Host '[refresh]  - the transfer folder must exist next to this script'
    $rc = 1
}

$stream.Close()
$client.Close()
exit $rc
