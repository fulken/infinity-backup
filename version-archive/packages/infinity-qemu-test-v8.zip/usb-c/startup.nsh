echo === INFINITY phase C: load driver then boot Windows ===
if exist FS0:\memory.efi then
  echo Loading driver from FS0
  load FS0:\memory.efi
endif
if exist FS1:\memory.efi then
  echo Loading driver from FS1
  load FS1:\memory.efi
endif
if exist FS2:\memory.efi then
  echo Loading driver from FS2
  load FS2:\memory.efi
endif
if exist FS3:\memory.efi then
  echo Loading driver from FS3
  load FS3:\memory.efi
endif
if exist FS4:\memory.efi then
  echo Loading driver from FS4
  load FS4:\memory.efi
endif
echo === driver stage done ===
if exist FS0:\EFI\Microsoft\Boot\bootmgfw.efi then
  echo Booting Windows from FS0
  FS0:\EFI\Microsoft\Boot\bootmgfw.efi
  echo FS0 bootloader returned
endif
if exist FS1:\EFI\Microsoft\Boot\bootmgfw.efi then
  echo Booting Windows from FS1
  FS1:\EFI\Microsoft\Boot\bootmgfw.efi
  echo FS1 bootloader returned
endif
if exist FS2:\EFI\Microsoft\Boot\bootmgfw.efi then
  echo Booting Windows from FS2
  FS2:\EFI\Microsoft\Boot\bootmgfw.efi
  echo FS2 bootloader returned
endif
if exist FS3:\EFI\Microsoft\Boot\bootmgfw.efi then
  echo Booting Windows from FS3
  FS3:\EFI\Microsoft\Boot\bootmgfw.efi
  echo FS3 bootloader returned
endif
if exist FS4:\EFI\Microsoft\Boot\bootmgfw.efi then
  echo Booting Windows from FS4
  FS4:\EFI\Microsoft\Boot\bootmgfw.efi
  echo FS4 bootloader returned
endif
echo === ERROR: Windows not found. Run phase-b.bat first ===
