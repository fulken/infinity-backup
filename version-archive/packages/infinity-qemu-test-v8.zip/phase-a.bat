@echo off
rem ============================================================
rem INFINITY Phase A test: boot memory.efi in QEMU/OVMF.
rem Requires: QEMU for Windows installed (qemu-system-x86_64.exe)
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
where qemu-system-x86_64.exe >nul 2>&1 && set QEMU=qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found.
  echo Install QEMU from: https://qemu.weilnetz.de/w64/
  echo then open a NEW terminal and run this again.
  pause
  exit /b 1
)

if not exist vars mkdir vars
if not exist vars\OVMF_VARS_4M.fd copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul

echo [Phase A] Starting QEMU (TCG - slow boot is normal)...
echo [Phase A] Expect: blue INFINITY banner + SUCCESS message.
echo [Phase A] Close the QEMU window when done.

"%QEMU%" -machine q35 -m 2048 -accel tcg ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb,format=raw,id=usbdrv ^
 -device ide-hd,drive=usbdrv,bootindex=0 ^
 -net none -no-reboot -serial file:serial-phase-a.log

echo.
echo [Phase A] Done. serial-phase-a.log saved in this folder.
pause
