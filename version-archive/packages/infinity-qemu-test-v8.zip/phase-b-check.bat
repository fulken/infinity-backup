@echo off
rem ============================================================
rem INFINITY Phase B result check v6: boot the check disk and
rem dump the INFDIAG variable with dmpstore under our GUID.
rem Run this AFTER phase-d.bat / phase-c.bat (same vars file).
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
where qemu-system-x86_64.exe >nul 2>&1 && set QEMU=qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] QEMU not found.
  pause
  exit /b 1
)

echo [Check] Booting the check disk. The screen will show the INFDIAG
echo [Check] variable under GUID A1B2C3D4-E5F6-4789-9ABC-DEF012345678.
echo [Check] The 32 bytes decode as:
echo [Check]   44 46 4E 49            = magic (always)
echo [Check]   next 4 bytes           = stage:
echo [Check]     01 00 00 00          = 1 driver loaded
echo [Check]     02 00 00 00          = 2 EBS fired, cr3 and build captured
echo [Check]     03 00 00 00          = 3 RT hooks installed at SetVirtualAddressMap
echo [Check]     04 00 00 00          = 4 WINDOWS CALLED a hooked service
echo [Check]   then flags, win_build, os_cr3, hook_calls, last_status
echo [Check] v5 reminder: stage 3 with everything else zero means the
echo [Check] EBS write failed - v6 prints the exact error to the serial
echo [Check] log, so always send serial-phase-d.log together.
echo.

"%QEMU%" -machine q35 -m 2048 -accel tcg ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-check,format=raw,id=chkdrv ^
 -device ide-hd,drive=chkdrv,bootindex=0 ^
 -net none -no-reboot -serial file:serial-check.log

pause
