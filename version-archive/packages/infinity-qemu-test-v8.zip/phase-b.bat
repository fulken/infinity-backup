@echo off
rem ============================================================
rem INFINITY Phase B v3: install Windows 10 into the test VM.
rem
rem Why v3: v2 installs crashed with a BLUE SCREEN
rem (IRQL_NOT_LESS_OR_EQUAL) during "Getting files ready for
rem installation". The crash point MOVED between two tries
rem (stuck at 0, then died at 16 percent) - that means a race
rem condition in the virtualization layer, NOT a bad ISO (a
rem broken ISO always dies at the exact same file/percent) and
rem NOT our driver (memory.efi is not loaded in phase B at
rem all). v2 also used "-cpu max" together with WHPX, which
rem advertises CPU features that WHPX cannot always virtualize
rem correctly - a known recipe for IRQL blue screens when the
rem guest is under heavy load. The install.esd apply phase is
rem the heaviest moment of the whole install.
rem
rem v3 changes:
rem   - WHPX runs with "-cpu host" (the model WHPX is built for)
rem   - 2 vCPUs by default, 1-vCPU safe mode, TCG last resort
rem   - no network card during install (one less device)
rem   - fresh disk + fresh NVRAM option (default after a BSOD)
rem
rem Usage:  phase-b.bat "C:\path\to\Win10.iso" [1 or 2 or 3]
rem         (or drag the ISO file onto this .bat)
rem         1 = WHPX fast, 2 cores   (20-40 min, default)
rem         2 = WHPX safe, 1 core    (bit slower, dodges races)
rem         3 = TCG software emulation (2-5 hours, most stable)
rem ============================================================
setlocal
cd /d "%~dp0"
set ISO=%~1
if "%ISO%"=="" (
  echo [ERROR] Give me the Windows 10 x64 ISO path:
  echo    phase-b.bat "C:\Users\you\Downloads\Win10.iso"
  echo or drag the ISO file onto this .bat
  pause
  exit /b 1
)
if not exist "%ISO%" (
  echo [ERROR] ISO not found: %ISO%
  echo If the path has Persian characters, rename the ISO to win10.iso
  echo put it next to this file and drag it from there.
  pause
  exit /b 1
)

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found. Install QEMU from:
  echo https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)
for %%d in ("%QEMU%") do set QDIR=%%~dpd

echo [Setup] QEMU version:
"%QEMU%" --version
echo.

rem ------------------------------------------------------------
rem Old disk? After a mid-install blue screen the half-written
rem Windows on it is garbage and resume will not work.
rem ------------------------------------------------------------
if exist disk\win10.qcow2 (
  echo [Setup] Found an existing virtual disk: disk\win10.qcow2
  echo [Setup] If your last install never reached the Windows desktop,
  echo [Setup] that disk contains a broken half-install and resume is useless.
  choice /c FR /m "[Setup] Fresh reinstall and delete it, or try to Resume old disk"
  if errorlevel 2 goto disk_ok
  echo [Setup] Deleting old disk and NVRAM ...
  del /q disk\win10.qcow2
  if exist vars\OVMF_VARS_4M.fd del /q vars\OVMF_VARS_4M.fd
  echo [Setup] Deleted. Starting clean.
)
:disk_ok

if not exist vars mkdir vars
if not exist vars\OVMF_VARS_4M.fd copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul
if not exist disk mkdir disk
if not exist disk\win10.qcow2 (
  echo [Setup] Creating 64GB virtual disk - one time only, a few seconds...
  "%QDIR%qemu-img.exe" create -f qcow2 disk\win10.qcow2 64G
)

rem ------------------------------------------------------------
rem Acceleration: 2nd argument, or interactive menu
rem ------------------------------------------------------------
set MODE=%~2
if "%MODE%"=="1" goto mode_ok
if "%MODE%"=="2" goto mode_ok
if "%MODE%"=="3" goto mode_ok
set MODE=
echo [Setup] Acceleration mode:
echo   [1] WHPX fast - 2 cores   about 20-40 min  - recommended
echo   [2] WHPX safe - 1 core    a bit slower, dodges multi-core races
echo   [3] TCG - software emulation. SLOW: 2-5 hours, but immune
echo       to WHPX bugs. Use this if 1 and 2 blue-screen.
choice /c 123 /m "[Setup] Choose 1, 2 or 3"
if errorlevel 3 (set MODE=3) else if errorlevel 2 (set MODE=2) else (set MODE=1)
:mode_ok

echo.
echo [Phase B] Installing Windows into the VM. Mode %MODE% selected.
echo [Phase B] 1. A black QEMU window opens, wait 10-30 seconds.
echo [Phase B] 2. When it says "Press any key to boot from CD or DVD"
echo [Phase B]    PRESS A KEY FAST, otherwise setup will not start.
echo [Phase B] 3. The VM reboots itself 2-3 times during install: normal.
echo [Phase B]    After the first reboot DO NOT press any key anymore.
echo [Phase B]    If that message comes back, the install died again:
echo [Phase B]    close the window and continue with the next mode.
echo [Phase B] 4. After the Windows desktop appears you can close it.
echo.

if "%MODE%"=="3" goto run_tcg

rem ---------------- WHPX mode 1 or 2 ----------------
if "%MODE%"=="1" set SMP=2
if "%MODE%"=="2" set SMP=1
"%QEMU%" -machine q35 -m 4096 -smp %SMP% -cpu host -accel whpx ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=0 ^
 -drive if=none,file="%ISO%",format=raw,media=cdrom,id=winiso ^
 -device ide-cd,drive=winiso,bus=ide.1,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -serial file:serial-phase-b.log
set RC=%errorlevel%
if "%RC%"=="0" goto done
echo.
echo [Phase B] WHPX could not start, exit code %RC% - retrying with TCG.
echo [Phase B] TCG is SLOW: the install can take 2-5 HOURS.
echo.

:run_tcg
"%QEMU%" -machine q35 -m 4096 -smp 2 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=0 ^
 -drive if=none,file="%ISO%",format=raw,media=cdrom,id=winiso ^
 -device ide-cd,drive=winiso,bus=ide.1,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -serial file:serial-phase-b.log

:done
echo.
echo [Phase B] QEMU closed. serial-phase-b.log was saved in this folder.
echo.
echo [Phase B] IF YOU SAW A BLUE SCREEN DURING THE INSTALL:
echo   1. Run phase-b.bat again with the same ISO, choose mode 2.
echo   2. If it blue-screens again: run it once more, choose mode 3.
echo      TCG is slow but immune to WHPX bugs.
echo   3. If even TCG blue-screens: the ISO file itself is damaged.
echo      Report it - we will get a clean ISO instead.
echo.
echo [Phase B] IF WINDOWS REACHED THE DESKTOP: next step is phase-c.bat
pause
