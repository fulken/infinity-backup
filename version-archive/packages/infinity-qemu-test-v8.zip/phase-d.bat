@echo off
rem ============================================================
rem INFINITY Phase D v8: boot installed Windows WITH the RT build
rem (EARLY gRT hooks + hardened virtual path). Deep test.
rem
rem v8 changes vs v6/v7:
rem   - hooks are installed at DRIVER LOAD TIME (v7 strategy - it
rem     is what made Windows actually call them) with the v7 crash
rem     fixed (stop 0xF: unconverted physical pointer in the trace
rem     hex table - now RIP-relative; no stack buffers; no SSE in
rem     hook code; atomic counters).
rem   - trigger-test.ps1 is now v10 (privilege struct fix): real triggers
rem     SetFirmwareEnvironmentVariableEx (fixes old error 87) and
rem     reads the LIVE INFDIAG + the driver response - no reboot
rem     needed to see stage 4.
rem   - v8.1: trigger-test.ps1 v10 is PRE-PLACED in usb-d - no manual
rem     copying needed anymore. A pre-flight check below REFUSES to
rem     start with a stale script. NOTE: the VM sees usb-d as a
rem     SNAPSHOT taken at QEMU start - files copied into usb-d AFTER
rem     phase-d.bat is running will NOT appear inside Windows.
rem   - final INFDIAG persists when you SHUT DOWN Windows from
rem     inside the VM (ResetSystem hook).
rem
rem IMPORTANT: use the SAME acceleration mode number that your
rem Windows install finished with (same rule as phase-c).
rem
rem Requires: Windows already installed via phase-b.bat
rem Usage:   phase-d.bat [1 or 2 or 3]
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found.
  echo Install QEMU from: https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)

if not exist disk\win10.qcow2 (
  echo [ERROR] disk\win10.qcow2 not found.
  echo Run phase-b.bat first to install Windows into the VM.
  pause
  exit /b 1
)
rem ---- pre-flight: the trigger test script must be v10 ----
rem A stale copy shows the old privilege error again and wastes
rem a whole boot. The v10 script is pre-placed in usb-d by the
rem package - this gate only fails if an old file replaced it.
if not exist usb-d\trigger-test.ps1 (
  echo [ERROR] usb-d\trigger-test.ps1 not found.
  echo The package ships it pre-placed in usb-d. Re-extract the
  echo full package zip over this folder - do not copy scripts by hand.
  pause
  exit /b 1
)
findstr /I /C:"trigger test v10" usb-d\trigger-test.ps1 >nul 2>&1
if errorlevel 1 (
  echo [ERROR] usb-d\trigger-test.ps1 is NOT the v10 script.
  echo A stale old copy would fail with the privilege error again.
  echo Fix: extract the NEW package zip over this folder, so that
  echo usb-d\trigger-test.ps1 is replaced - v10 is 14290 bytes.
  pause
  exit /b 1
)
echo [Phase D] trigger-test.ps1 v10 verified - pre-placed on the boot disk.
echo [Phase D] NOTE: Windows sees usb-d as a SNAPSHOT taken at startup.
echo [Phase D] Files copied into usb-d after this point will NOT show up
echo [Phase D] inside the VM this boot. Stop the VM first, then copy, then
echo [Phase D] run phase-d.bat again.

if not exist vars mkdir vars
if not exist vars\OVMF_VARS_4M.fd copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul

set MODE=%~1
if "%MODE%"=="1" goto mode_ok
if "%MODE%"=="2" goto mode_ok
if "%MODE%"=="3" goto mode_ok
set MODE=
echo [Phase D] Acceleration: use the SAME mode number that your
echo [Phase D] Windows install finished with successfully.
echo   [1] WHPX fast - 2 cores
echo   [2] WHPX safe - 1 core
echo   [3] TCG - software emulation, slow boot
choice /c 123 /m "[Phase D] Choose 1, 2 or 3"
if errorlevel 3 (set MODE=3) else if errorlevel 2 (set MODE=2) else (set MODE=1)
:mode_ok

echo.
echo [Phase D] Windows + memory.efi v8 RT boot test. Mode %MODE% selected.
echo [Phase D] The banner must say: Build: v8 RT - EARLY gRT hooks (phase D3).
echo [Phase D] Watch for these milestone lines in serial-phase-d.log:
echo [Phase D]   [INF][RT-EARLY] gRT hooks INSTALLED at load time
echo [Phase D]   [INF][HOOK] G/S call#N BOOT-CTX  (shell/bootmgr chained OK)
echo [Phase D]   [INF][EBS] ExitBootServices hook FIRED   (stage 2)
echo [Phase D]   [INF][VA]  SetVirtualAddressMap ... FIRED (stage 3)
echo [Phase D]   [INF][HOOK] G/S/T call#N VIRT FIRST  (stage 4!)
echo [Phase D] After the desktop loads do NOT close the window yet:
echo [Phase D]   1. inside Windows open PowerShell as Administrator
echo [Phase D]   2. run D:\trigger-test.ps1 - it is ALREADY on the boot disk.
echo [Phase D]      Its FIRST output line must say: trigger test v10.
echo [Phase D]      It writes real triggers and reads the LIVE INFDIAG.
echo [Phase D]   3. SHUT DOWN Windows from inside the VM (this saves
echo [Phase D]      the final INFDIAG via the ResetSystem hook)
echo [Phase D]   4. then run phase-b-check.bat
echo [Phase D] If Windows hangs, resets or BSODs, that IS a valuable
echo [Phase D] result - keep the serial log and send it.
echo.

if "%MODE%"=="3" goto run_tcg

rem ---------------- WHPX mode 1 or 2 ----------------
if "%MODE%"=="1" set SMP=2
if "%MODE%"=="2" set SMP=1
"%QEMU%" -machine q35 -m 4096 -smp %SMP% -cpu host -accel whpx ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-d,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-d.log
set RC=%errorlevel%
if "%RC%"=="0" goto done
echo.
echo [Phase D] WHPX could not start, exit code %RC% - retrying with TCG.
echo.

:run_tcg
"%QEMU%" -machine q35 -m 4096 -smp 2 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-d,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-d.log

:done
echo.
echo [Phase D] Done. Next steps:
echo   1. run phase-b-check.bat and send a photo of the INFDIAG line
echo   2. send serial-phase-d.log (contains the [INF] diagnostic lines)
echo   3. send the output of trigger-test.ps1 if you ran it
echo   4. tell me which mode number you used
pause
