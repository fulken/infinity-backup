@echo off
rem ============================================================
rem INFINITY Phase C v3: boot the installed Windows WITH the
rem memory.efi driver loaded. This is the real test.
rem
rem Flow: USB ritual boots the EFI Shell -> startup.nsh loads
rem memory.efi -> finds the Windows Boot Manager on the virtual
rem disk -> launches it -> Windows boots with the driver resident
rem (ExitBootServices hook + CR3 capture + build detection all
rem fire during this boot).
rem
rem v3: same acceleration menu as phase-b v3. IMPORTANT: choose
rem the SAME mode number that installed your Windows. If your
rem host WHPX is unstable, a crash here would be blamed on our
rem driver unfairly - same mode = fair test.
rem
rem Requires: Windows already installed via phase-b.bat
rem Usage:   phase-c.bat [1 or 2 or 3]
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe not found.
  echo Install QEMU from: https://qemu.weilnetz.de/w64/
  pause
  exit /b 1
)

if not exist disk\win10.qcow2 (
  echo [ERROR] disk\win10.qcow2 not found.
  echo Run phase-b.bat first to install Windows into the VM.
  pause
  exit /b 1
)

if not exist vars mkdir vars
if not exist vars\OVMF_VARS_4M.fd copy /y firmware\OVMF_VARS_4M.fd vars\OVMF_VARS_4M.fd >nul

set MODE=%~1
if "%MODE%"=="1" goto mode_ok
if "%MODE%"=="2" goto mode_ok
if "%MODE%"=="3" goto mode_ok
set MODE=
echo [Phase C] Acceleration: use the SAME mode number that your
echo [Phase C] Windows install finished with successfully.
echo   [1] WHPX fast - 2 cores
echo   [2] WHPX safe - 1 core
echo   [3] TCG - software emulation, slow boot
choice /c 123 /m "[Phase C] Choose 1, 2 or 3"
if errorlevel 3 (set MODE=3) else if errorlevel 2 (set MODE=2) else (set MODE=1)
:mode_ok

echo.
echo [Phase C] Windows + memory.efi boot test. Mode %MODE% selected.
echo [Phase C] Flow: blue INFINITY banner -^> driver loads -^>
echo [Phase C] "Booting Windows" -^> Windows boots with the driver resident.
echo [Phase C] If Windows hangs, resets or the window closes by itself,
echo [Phase C] that IS a test result we need - do not worry, keep the log.
echo [Phase C] Close the window once the desktop is up.
echo.

if "%MODE%"=="3" goto run_tcg

rem ---------------- WHPX mode 1 or 2 ----------------
if "%MODE%"=="1" set SMP=2
if "%MODE%"=="2" set SMP=1
"%QEMU%" -machine q35 -m 4096 -smp %SMP% -cpu host -accel whpx ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-c,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-c.log
set RC=%errorlevel%
if "%RC%"=="0" goto done
echo.
echo [Phase C] WHPX could not start, exit code %RC% - retrying with TCG.
echo.

:run_tcg
"%QEMU%" -machine q35 -m 4096 -smp 2 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-c,format=raw,id=bootdrv ^
 -device ide-hd,drive=bootdrv,bus=ide.1,bootindex=0 ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=1 ^
 -nic none -usb -device usb-tablet ^
 -no-reboot -serial file:serial-phase-c.log

:done
echo.
echo [Phase C] Done. Now run phase-b-check.bat, then send me:
echo   1. a photo of the INFDIAG variable on screen
echo   2. the serial-phase-c.log file
echo   3. which mode number you used
pause
