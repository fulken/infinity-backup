echo === INFINITY test: loading memory.efi ===
load FS0:\memory.efi
echo === load returned. Check the banner above. ===
echo === For Phase B the OS will boot next automatically. ===
echo === For Phase A you can close the QEMU window now. ===
