echo === INFINITY result check ===
echo === INFDIAG lives under the driver vendor GUID.
echo === dmpstore without -guid searches only the global GUID
echo === and always says "No matching variables found".
echo ===
echo === Stage 1 = safe-path build complete. This is the EXPECTED
echo ===        and BEST result for the current driver build.
echo === Stage 3 = runtime hook called by Windows. Only possible
echo ===        with the phase-D build, never with this binary.
dmpstore INFDIAG* -guid A1B2C3D4-E5F6-4789-9ABC-DEF012345678
echo === end ===
