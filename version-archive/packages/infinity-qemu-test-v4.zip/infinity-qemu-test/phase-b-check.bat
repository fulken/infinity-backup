@echo off
rem ============================================================
rem INFINITY result check v2: boot the check disk and dump the
rem INFDIAG variable with dmpstore + the correct vendor GUID.
rem
rem v1 bug (user found it): "dmpstore INFDIAG*" without -guid
rem searches only the EFI global-variable GUID and always prints
rem "No matching variables found". The driver writes INFDIAG
rem under its own vendor GUID:
rem   A1B2C3D4-E5F6-4789-9ABC-DEF012345678
rem The startup.nsh now passes -guid, matching the manual command
rem that already worked on the real bench.
rem
rem Stage semantics:
rem   01 = safe-path build completed (load + EBS hook chain).
rem        This is the EXPECTED result with the current build -
rem        seeing it after a full Windows boot to the desktop
rem        means the test is GREEN.
rem   03 = runtime hook called by Windows itself. Requires the
rem        phase-D build; the shipped binary cannot produce it.
rem ============================================================
setlocal
cd /d "%~dp0"

set QEMU=
where qemu-system-x86_64.exe >nul 2>&1 && set QEMU=qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe
if not defined QEMU (
  echo [ERROR] QEMU not found.
  pause
  exit /b 1
)

echo [Check] Booting result disk. The screen will show the INFDIAG
echo [Check] variable data. Look for the hex bytes after the GUID:
echo [Check]   44 46 4E 49 = magic
echo [Check]   01 00 00 00 = stage 1 = SAFE-PATH COMPLETE (green)
echo [Check]   03 00 00 00 = stage 3 = phase-D build only
echo [Check] Everything after stage staying zero is normal for this build.

"%QEMU%" -machine q35 -m 2048 -accel tcg ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=fat:rw:usb-check,format=raw,id=chkdrv ^
 -device ide-hd,drive=chkdrv,bootindex=0 ^
 -nic none -no-reboot -serial file:serial-check.log

pause
