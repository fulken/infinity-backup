@echo off
rem ============================================================
rem INFINITY refresh-files - push files into the RUNNING VM.
rem
rem 1. Put your files into the "transfer" folder next to this
rem    file (create it if the script has not done so yet).
rem 2. Double-click THIS file while the VM is running.
rem 3. A USB stick with your files appears inside Windows in
rem    the VM a few seconds later - NO restart needed.
rem
rem Requires: VM started with phase-d.bat from package v19+.
rem ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0refresh-files.ps1" %*
echo.
pause
