# ============================================================
# INFINITY bridge trigger test v7  (run INSIDE the Windows VM,
# in an ELEVATED PowerShell: "Run as Administrator")
#
# What changed vs v6/v8 (root-cause fixes):
#   1. The v8 script declared SetFirmwareEnvironmentVariable as
#      (name, buffer, size, guid) — the REAL API order is
#      (name, guid, value, size). With the wrong order lpGuid
#      received the payload pointer, GUID parsing failed, and
#      the API returned Win32 87 (ERROR_INVALID_PARAMETER)
#      WITHOUT the call ever reaching the firmware.
#   2. We now use SetFirmwareEnvironmentVariableExW with explicit
#      EFI attributes (NON_VOLATILE | BOOTSERVICE | RUNTIME).
#   3. The trigger variable name the driver actually answers to
#      is "InfinityReq" (not "INFTRIGGER") under GUID
#      {A1B2C3D4-E5F6-4789-9ABC-DEF012345678}.
#   4. The payload is a real EfiVarReq (48 bytes) with op=PING
#      (0xDEADBEEF); the response is read back from "InfinityResp"
#      (EfiVarResp, 32 bytes) and decoded.
#
# Test flow:
#   [1] Enable SeSystemEnvironmentPrivilege (v7 fixed struct).
#   [2] Read INFDIAG twice — with the v7 RT driver each read goes
#       THROUGH our hook, so the first read itself should bump
#       stage 3 -> 4. Stage change between reads = hook ALIVE.
#   [3] Write InfinityReq (PING, sequence 0x1337).
#   [4] Read InfinityResp — matching sequence + status 1 = the
#       driver PROCESSED our request. Full bridge proven.
#   [5] Read INFDIAG again (final state).
#
# Expected results (v7 RT driver):
#   - READ2 shows STAGE=4 + hook_calls >= 1   -> hook chain alive
#   - RESP  sequence=0x1337, status=1         -> full bridge OK
#   - Win32 1314 -> PowerShell not elevated
#   - Win32 2    on InfinityResp -> write never reached the driver
#     (SAFE build loaded, or the OS bypassed the hooks - report!)
# ============================================================

$ErrorActionPreference = 'Continue'

$src = @'
using System;
using System.Runtime.InteropServices;

public static class EfiVarBridge {
    // ---- privilege enabling (v7 struct fix: LUID + LUID_AND_ATTRIBUTES)
    [StructLayout(LayoutKind.Sequential)]
    public struct LUID { public uint LowPart; public int HighPart; }

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID_AND_ATTRIBUTES {
        public LUID Luid;
        public uint Attributes;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES {
        public uint PrivilegeCount;
        public LUID_AND_ATTRIBUTES Privileges;
    }

    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

    [DllImport("kernel32.dll")]
    static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out LUID lpLuid);

    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool AdjustTokenPrivileges(IntPtr TokenHandle, bool DisableAllPrivileges,
        ref TOKEN_PRIVILEGES NewState, uint BufferLength, IntPtr PreviousState, IntPtr ReturnLength);

    // ---- firmware variable APIs (v7: CORRECT parameter order)
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern uint GetFirmwareEnvironmentVariableW(
        string lpName, string lpGuid, byte[] pBuffer, uint nSize);

    // BOOL SetFirmwareEnvironmentVariableExW(
    //     LPCWSTR lpName, LPCWSTR lpGuid, PVOID pValue, DWORD nSize,
    //     DWORD dwAttributes)
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool SetFirmwareEnvironmentVariableExW(
        string lpName, string lpGuid, byte[] pValue, uint nSize, uint dwAttributes);

    public static bool EnablePriv(string name) {
        IntPtr token;
        if (!OpenProcessToken(GetCurrentProcess(), 0x28, out token))
            return false;
        LUID luid;
        if (!LookupPrivilegeValue(null, name, out luid))
            return false;
        TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
        tp.PrivilegeCount = 1;
        tp.Privileges.Luid = luid;
        tp.Privileges.Attributes = 2;   // SE_PRIVILEGE_ENABLED
        return AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
    }
}
'@

Add-Type -TypeDefinition $src -Language CSharp

# ---- constants (must match Memory/include/SharedMemoryProtocol.h + RuntimeHook.h)
$guid    = '{A1B2C3D4-E5F6-4789-9ABC-DEF012345678}'
$attrs   = 0x7            # EFI_VARIABLE_NON_VOLATILE | BOOTSERVICE_ACCESS | RUNTIME_ACCESS
$ReqOp_Ping        = 0xDEADBEEF
$SlotStatus_Success = 1

function U32([byte[]]$b, [int]$o) { return $b[$o] -bor ($b[$o+1] -shl 8) -bor ($b[$o+2] -shl 16) -bor ($b[$o+3] -shl 24) }
function U64([byte[]]$b, [int]$o) {
    $v = [uint64]0
    for ($i = 7; $i -ge 0; $i--) { $v = ($v -shl 8) -bor $b[$o+$i] }
    return $v
}

function Read-EfiVar([string]$name, [byte[]]$buf) {
    # Returns the number of bytes read (0 on failure, sets $script:LastErr).
    $n = [EfiVarBridge]::GetFirmwareEnvironmentVariableW($name, $guid, $buf, [uint32]$buf.Length)
    $script:LastErr = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    return [int]$n
}

function Read-Infdiag([string]$Label) {
    $buf = New-Object byte[] 64
    $n = Read-EfiVar 'INFDIAG' $buf
    if ($n -le 0) {
        Write-Host "[$Label] INFDIAG read failed, Win32Error=$LastErr"
        switch ($LastErr) {
            1314 { Write-Host "[$Label]   -> privilege not held (not elevated?)" }
            2    { Write-Host "[$Label]   -> variable not found (driver never loaded this boot?)" }
            87   { Write-Host "[$Label]   -> invalid parameter" }
        }
        return $null
    }
    $hex = ($buf[0..($n-1)] | ForEach-Object { $_.ToString('X2') }) -join ' '
    Write-Host "[$Label] INFDIAG ($n bytes): $hex"
    if ($n -ge 32 -and $buf[0] -eq 0x44 -and $buf[1] -eq 0x46 -and $buf[2] -eq 0x4E -and $buf[3] -eq 0x49) {
        $stage   = U32 $buf 4
        $flags   = U32 $buf 8
        $build   = U32 $buf 12
        $cr3     = U64 $buf 16
        $calls   = U32 $buf 24
        $lastst  = U32 $buf 28
        $flagTxt = @()
        if ($flags -band 0x1) { $flagTxt += 'loaded' }
        if ($flags -band 0x2) { $flagTxt += 'EBS-fired' }
        if ($flags -band 0x4) { $flagTxt += 'virtual' }
        if ($flags -band 0x8) { $flagTxt += 'EARLY-hooks' }
        Write-Host ("[$Label] STAGE={0}  flags=0x{1:X} ({2})  win_build={3}  os_cr3=0x{4:X}  hook_calls={5}  last_status=0x{6:X}" -f $stage, $flags, ($flagTxt -join ','), $build, $cr3, $calls, $lastst)
        return $stage
    }
    Write-Host "[$Label] (magic bytes do not match INFDIAG - unexpected data)"
    return $null
}

# ============================================================
Write-Host '=== INFINITY bridge trigger test v7 ==='
Write-Host ''

# [0] privilege
if (-not [EfiVarBridge]::EnablePriv('SeSystemEnvironmentPrivilege')) {
    Write-Host '[ERROR] privilege enable call failed - run PowerShell as Administrator.'
    exit 1
}
Write-Host '[0] SeSystemEnvironmentPrivilege enabled.'

# [1] double INFDIAG read (hook-alive proof without writing anything)
Write-Host ''
Write-Host '[1] INFDIAG double read (stage bump between reads = hook ALIVE):'
$s1 = Read-Infdiag 'READ1'
Start-Sleep -Milliseconds 400
$s2 = Read-Infdiag 'READ2'

# [2] build the 48-byte EfiVarReq PING request
$seq = 0x1337
$req = New-Object byte[] 48
[BitConverter]::GetBytes([uint32]$seq).CopyTo($req, 0)       # sequence
[BitConverter]::GetBytes([uint32]$ReqOp_Ping).CopyTo($req, 4) # op = PING
# pid, data_size, address, alloc_size, protect, timeout_ms, status, crc32 all zero

Write-Host ''
Write-Host ("[2] Writing InfinityReq (PING, sequence=0x{0:X}, 48 bytes, attrs=0x7)..." -f $seq)
$ok = [EfiVarBridge]::SetFirmwareEnvironmentVariableExW('InfinityReq', $guid, $req, [uint32]$req.Length, [uint32]$attrs)
$werr = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
if ($ok) {
    Write-Host '[OK] InfinityReq write accepted.'
} else {
    Write-Host "[FAIL] InfinityReq write failed, Win32Error=$werr"
    switch ($werr) {
        1314 { Write-Host '   -> privilege not held (not elevated?)' }
        87   { Write-Host '   -> invalid parameter (check name/GUID/attrs)' }
        5    { Write-Host '   -> access denied (policy blocks firmware writes?)' }
    }
}

# [3] read the response
Start-Sleep -Milliseconds 300
Write-Host ''
Write-Host '[3] Reading InfinityResp...'
$rbuf = New-Object byte[] 64
$rn = Read-EfiVar 'InfinityResp' $rbuf
if ($rn -ge 32) {
    $rhex = ($rbuf[0..($rn-1)] | ForEach-Object { $_.ToString('X2') }) -join ' '
    Write-Host "[OK] InfinityResp ($rn bytes): $rhex"
    $rseq = U32 $rbuf 0
    $rstat = U32 $rbuf 4
    $rxfer = U64 $rbuf 8
    $raddr = U64 $rbuf 16
    Write-Host ("     sequence=0x{0:X}  status={1}  bytes_transferred={2}  out_address=0x{3:X}" -f $rseq, $rstat, $rxfer, $raddr)
    if ($rseq -eq $seq -and $rstat -eq $SlotStatus_Success) {
        Write-Host '     >>> PING ANSWERED BY THE DRIVER - FULL BRIDGE ALIVE! <<<'
    } else {
        Write-Host '     -> response received but sequence/status mismatch - send this output.'
    }
} elseif ($rn -eq 0 -and $LastErr -eq 2) {
    Write-Host '[FAIL] InfinityResp not found (error 2).'
    Write-Host '   -> The InfinityReq write never reached the driver (SAFE build loaded,'
    Write-Host '      or the OS is not routing variable calls through the hooks).'
    Write-Host '   -> Send this output + serial-phase-d.log for analysis.'
} else {
    Write-Host "[FAIL] InfinityResp read: n=$rn Win32Error=$LastErr"
}

# [4] final INFDIAG
Write-Host ''
Write-Host '[4] Final INFDIAG state:'
$s3 = Read-Infdiag 'READ3'

# ============================================================
Write-Host ''
Write-Host '=== VERDICT ==='
$fullChain = $false
if ($null -ne $s2) {
    if ($s1 -ne $null -and $s1 -ne $s2) {
        Write-Host "RESULT: stage changed between READ1 and READ2 ($s1 -> $s2): OUR HOOK RAN INSIDE WINDOWS."
        $fullChain = $true
    } elseif ($s2 -ge 4) {
        Write-Host 'RESULT: stage 4 - a hooked service was already called by Windows. CHAIN ALIVE.'
        $fullChain = $true
    } elseif ($s2 -eq 3) {
        Write-Host 'RESULT: stage 3 - hooks installed but Windows did not call one through gRT.'
        Write-Host '  (If this is the v7 EARLY-hooks driver, report this - it means the'
        Write-Host '   snapshot theory needs revising. Send output + serial-phase-d.log.)'
    } else {
        Write-Host "RESULT: stage $s2 - unexpected. Send this output plus serial-phase-d.log."
    }
}
if ($fullChain) {
    Write-Host 'RESULT: Runtime hook chain PROVEN on Windows - phase D complete.'
}
Write-Host '=== END v7 ==='
