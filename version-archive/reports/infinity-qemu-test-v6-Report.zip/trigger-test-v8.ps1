# INFINITY trigger-test v8
# Full UEFI runtime trigger test. Run as Administrator.

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class WinFw {
[DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr h,uint a,out IntPtr t);
[DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
[DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool LookupPrivilegeValue(string s,string n,out LUID l);
[DllImport("advapi32.dll",SetLastError=true)] static extern bool AdjustTokenPrivileges(IntPtr t,bool d,ref TP p,uint b,IntPtr x,IntPtr y);
[DllImport("kernel32.dll",SetLastError=true)] public static extern uint GetFirmwareEnvironmentVariable(string n,string g,byte[] b,uint s);
[DllImport("kernel32.dll",SetLastError=true)] public static extern bool SetFirmwareEnvironmentVariable(string n,byte[] b,uint s,string g);
[StructLayout(LayoutKind.Sequential)] public struct LUID { public uint Low; public int High; }
[StructLayout(LayoutKind.Sequential)] public struct LA { public LUID L; public uint A; }
[StructLayout(LayoutKind.Sequential)] public struct TP { public uint C; public LA P; }
public static bool Enable(string n){
 IntPtr t; if(!OpenProcessToken(GetCurrentProcess(),0x28,out t)) return false;
 LUID l; if(!LookupPrivilegeValue(null,n,out l)) return false;
 TP p=new TP(); p.C=1; p.P.L=l; p.P.A=2;
 return AdjustTokenPrivileges(t,false,ref p,0,IntPtr.Zero,IntPtr.Zero);
}
}
"@

Write-Host "=== INFINITY trigger test v8 ==="

$guid="{A1B2C3D4-E5F6-4789-9ABC-DEF012345678}"

if([WinFw]::Enable("SeSystemEnvironmentPrivilege")){
 Write-Host "[OK] privilege enabled"
}else{
 Write-Host "[FAIL] privilege enable failed"
}

function Read-InfDiag {
 $b=New-Object byte[] 64
 $n=[WinFw]::GetFirmwareEnvironmentVariable("INFDIAG",$guid,$b,64)
 if($n -gt 0){
  Write-Host ("INFDIAG: "+(($b[0..($n-1)]|%{$_.ToString("X2")}) -join " "))
 }else{
  Write-Host "INFDIAG read failed Win32=$([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
 }
}

Write-Host "[1] Before trigger"
Read-InfDiag

Write-Host "[2] Writing INFTRIGGER"
$d=[byte[]](0x49,0x4E,0x46,0x54,0x52,0x49,0x47,0x47,0x45,0x52)

if([WinFw]::SetFirmwareEnvironmentVariable("INFTRIGGER",$d,$d.Length,$guid)){
 Write-Host "[OK] trigger write"
}else{
 Write-Host "trigger write failed Win32=$([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
}

Start-Sleep 2

Write-Host "[3] After trigger"
Read-InfDiag

Write-Host "=== END v8 ==="
