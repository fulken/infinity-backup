@echo off
rem ============================================================
rem Finish Windows 10 OOBE using the EXISTING installed VM.
rem
rem - Does NOT delete or recreate disk\win10.qcow2
rem - Does NOT delete or recreate vars\OVMF_VARS_4M.fd
rem - Does NOT attach the Windows ISO
rem - Uses TCG (2 vCPUs, 8 GB RAM)
rem - Adds an e1000e network adapter so Windows OOBE can get network
rem ============================================================

setlocal
cd /d "%~dp0"

set QEMU=
for /f "delims=" %%p in ('where qemu-system-x86_64.exe 2^>nul') do if not defined QEMU set "QEMU=%%p"
if not defined QEMU if exist "%ProgramFiles%\qemu\qemu-system-x86_64.exe" set "QEMU=%ProgramFiles%\qemu\qemu-system-x86_64.exe"
if not defined QEMU if exist "%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe" set "QEMU=%ProgramFiles(x86)%\qemu\qemu-system-x86_64.exe"

if not defined QEMU (
  echo [ERROR] qemu-system-x86_64.exe was not found.
  pause
  exit /b 1
)

if not exist "disk\win10.qcow2" (
  echo [ERROR] Existing Windows disk was not found:
  echo         disk\win10.qcow2
  echo.
  echo Put this BAT file in the same project folder as phase-b.bat.
  pause
  exit /b 1
)

if not exist "vars\OVMF_VARS_4M.fd" (
  echo [ERROR] Existing NVRAM was not found:
  echo         vars\OVMF_VARS_4M.fd
  echo.
  echo Do NOT create a fresh one here; the installed Windows boot entry may be in it.
  pause
  exit /b 1
)

if not exist "firmware\OVMF_CODE_4M.fd" (
  echo [ERROR] Firmware file was not found:
  echo         firmware\OVMF_CODE_4M.fd
  pause
  exit /b 1
)

echo.
echo [OOBE] Booting the EXISTING Windows install with TCG + network.
echo [OOBE] Disk and NVRAM will NOT be deleted or recreated.
echo [OOBE] No Windows ISO is attached.
echo [OOBE] RAM: 8 GB   vCPU: 2
echo.
echo When Windows opens, continue the setup/OOBE normally.
echo Do not run phase-b.bat again while this VM is open.
echo.

"%QEMU%" -machine q35 -m 8192 -smp 2 -cpu max -accel tcg ^
 -rtc base=localtime ^
 -drive if=pflash,format=raw,readonly=on,file=firmware\OVMF_CODE_4M.fd ^
 -drive if=pflash,format=raw,file=vars\OVMF_VARS_4M.fd ^
 -drive if=none,file=disk\win10.qcow2,format=qcow2,id=windisk ^
 -device ide-hd,drive=windisk,bus=ide.0,bootindex=0 ^
 -netdev user,id=net0 ^
 -device e1000e,netdev=net0 ^
 -usb -device usb-tablet ^
 -serial file:serial-finish-oobe.log

echo.
echo [OOBE] QEMU closed.
echo [OOBE] serial-finish-oobe.log was saved in this folder.
pause
