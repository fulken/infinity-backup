# ============================================================
# INFINITY bridge trigger test v20  (run INSIDE the Windows VM,
# in an ELEVATED PowerShell: "Run as Administrator")
#
# REQUIRES the v17 driver stick (memory.efi v17 RT - "bridge +
# kernel data path (phase E)"). The DRIVER IS NOT CHANGED by v20;
# only this test script is fixed.
#
# WHAT HAPPENED IN v17: steps A..H all PASSED (full bridge +
# payload transport PROVEN). Steps I..M never executed - every
# kernel-data-path call died with:
#     "Cannot overwrite variable pid because it is read-only"
# $PID is an automatic READ-ONLY PowerShell variable; the v17
# helper used it as a parameter name, so the request packet was
# NEVER written. The "-1" results were script artifacts, not
# driver answers. (Proof: no [RD] lines in serial, and INFCNT
# stopped exactly where the crashes started.)
#
# WHAT HAPPENED IN v18 (see the v18 report): steps A..H all
# PASSED AGAIN - including a byte-perfect PONG (raw response
# 37 13 00 00 01 00 00 00 = seq 0x1337, status 1 Success).
# But steps I..M died with "request byte build failed (header
# mismatch)" and the summary cried BRIDGE REGRESSION - BOTH were
# false alarms from ONE parser bug: PS 5.1 keeps the LEFT
# operand's type for -shl, so U32's ([byte] -shl 8) truncated to
# 8 bits and every dword collapsed to its LOW BYTE (0x1337 shown
# as 0x37, win_build 19045 as 101, hook_calls 315 as 59). The
# driver itself was NEVER wrong.
#
# v20 FIXES (script only):
#   1. step I (ReqOp_Attach, op=7) REMOVED - the v19 run crashed the
#      whole VM on it. Root cause found by disassembling the v17 driver
#      binary: op=7 walks the Windows process list hunting for emulator
#      EXEs (aow_exe.exe / AndroidProcess.exe / LdVBoxHeadless.exe /
#      HD-Player.exe) that do not exist in this plain Windows VM ->
#      fault in firmware context -> triple fault. Attachment is NOT
#      needed for kernel-target reads (pid=FFFFFFFF uses the current-CR3
#      page walk directly) - steps J..M now run first.
#   2. self-test 0xFFFFFFFF check fixed: [uint32]0xFFFFFFFF threw on
#      PS 5.1 (trap #4: hex literals 0x80000000..0xFFFFFFFF parse as
#      negative Int32) - now [Convert]::ToUInt32('FFFFFFFF', 16)
#   3. disassembly-verified expectations: response = [seq@0][status@4]
#      [xfer@8][out@0x10], READ DATA lands in the InfinityData buffer,
#      non-canonical VA is rejected CLEANLY (status 4, no crash)
#
# v19 FIXES (script only):
#   1. U32 rewritten with an explicit [uint32] accumulator (the
#      field-proven U64 pattern) - all 32 bits survive
#   2. PARSER SELF-TEST at startup: U32/U64/HexLe4/New-Req are
#      verified on known patterns BEFORE the driver is touched;
#      any mismatch aborts loudly instead of wasting a test cycle
#   3. summary win_build line now COMPUTES equal/mismatch
#      (v18 hardcoded "(equal...)" even while showing 101 vs 19045)
#
# v18 fixes kept (script only):
#   1. helper parameters renamed (rpid / raddr / ...) - no
#      automatic variable is ever assigned anywhere
#   2. every response is dumped RAW and decoded at EVERY
#      plausible dword offset, plus the InfinityData buffer, so
#      the kernel-read data location cannot hide
#   3. step N expectation corrected: consumed InfinityReq writes
#      (E, I..M) never bump INFCNT - expect N = G + 1, not 8
#
# Step map:
#   A,B  INFDIAG reads          -> hook_calls must MOVE (read path)
#   C    INFPROBE write+read    -> raw NVRAM write path
#   D    INFTRIGGER write       -> trigger flag 0x20 + INFCNT
#   E    InfinityReq PING       -> the request transport
#   E2   InfinityResp read      -> FULL BRIDGE check (PONG)
#   F    final INFDIAG + read-backs
#   G    INFCNT read            -> live RAM write counter
#   H    InfinityData 32B round trip -> payload transport
#   I    ReqOp_Attach (op=7)  SKIPPED IN v20 - VM-fatal (see note at step I)
#   J    ReqOp_Read   (op=1, kernel, KUSD+0x260 x4)    -> expect 19045 (0x4A65)
#   K    ReqOp_Read   (op=1, kernel, KUSD+0x308 x4)    -> expect 0
#   L    ReqOp_Read   (op=1, kernel, KUSD+0x260 x8)    -> dword[0] must equal J
#   M    ReqOp_Read   (op=1, kernel, NON-CANONICAL VA) -> ErrAccess(4), no crash
#   N    final INFCNT -> expect G+1 (only InfinityData persists)
#
# Win32 203 = ERROR_ENVVAR_NOT_FOUND (normal "variable absent").
# stage=4 is EXPECTED (virtual mode armed - OS runtime calls count).
# ============================================================

$ErrorActionPreference = 'Continue'

$src = @'
using System;
using System.Runtime.InteropServices;

public static class EfiVarBridge {
    // ---- privilege enabling (struct fix from v7)
    [StructLayout(LayoutKind.Sequential)]
    public struct LUID { public uint LowPart; public int HighPart; }

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID_AND_ATTRIBUTES {
        public LUID Luid;
        public uint Attributes;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES {
        public uint PrivilegeCount;
        public LUID_AND_ATTRIBUTES Privileges;
    }

    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

    [DllImport("kernel32.dll")]
    static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out LUID lpLuid);

    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool AdjustTokenPrivileges(IntPtr TokenHandle, bool DisableAllPrivileges,
        ref TOKEN_PRIVILEGES NewState, uint BufferLength, IntPtr PreviousState, IntPtr ReturnLength);

    // ---- firmware variable APIs (v7 correct parameter order)
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern uint GetFirmwareEnvironmentVariableW(
        string lpName, string lpGuid, byte[] pBuffer, uint nSize);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool SetFirmwareEnvironmentVariableExW(
        string lpName, string lpGuid, byte[] pValue, uint nSize, uint dwAttributes);

    public static bool EnablePriv(string name) {
        IntPtr token;
        if (!OpenProcessToken(GetCurrentProcess(), 0x28, out token))
            return false;
        LUID luid;
        if (!LookupPrivilegeValue(null, name, out luid))
            return false;
        TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
        tp.PrivilegeCount = 1;
        tp.Privileges.Luid = luid;
        tp.Privileges.Attributes = 2;   // SE_PRIVILEGE_ENABLED
        return AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
    }
}
'@

if (-not ("EfiVarBridge" -as [type])) {
    try { Add-Type -TypeDefinition $src -Language CSharp }
    catch {
        Write-Host '[ABORT] Add-Type failed (unexpected). Send the output .txt / a photo of this window.'
        Write-Host $_.Exception.Message
        exit 1
    }
}

# ---- constants ------------------------------------------------------
$guid  = '{A1B2C3D4-E5F6-4789-9ABC-DEF012345678}'
$attrs = 0x7    # EFI_VARIABLE_NON_VOLATILE | BOOTSERVICE | RUNTIME

# ---- helpers --------------------------------------------------------
function HexLe4([string]$hex) {
    # 'DEADBEEF' -> bytes EF BE AD DE (little endian), from hex STRING
    # (PowerShell hex-literal sign trap = the v10 bug, never again).
    $h = $hex.PadLeft(8, '0')
    $b = New-Object byte[] 4
    for ($i = 0; $i -lt 4; $i++) {
        $b[$i] = [Convert]::ToByte($h.Substring(6 - 2 * $i, 2), 16)
    }
    return $b
}

function U32([byte[]]$b, [int]$o) {
    # v19 FIX: in PS 5.1 -shl keeps the LEFT operand's type, so the old
    # one-liner's ([byte] -shl 8) truncated to 8 bits and every dword
    # collapsed to its low byte (0x1337 read as 0x37, build 19045 as 101,
    # hook_calls 315 as 59 - all seen live in the v18 report). An explicit
    # [uint32] accumulator - the U64 pattern, field-proven since v12 -
    # keeps all 32 bits.
    $v = [uint32]0
    for ($i = 3; $i -ge 0; $i--) { $v = ($v -shl 8) -bor [uint32]$b[$o+$i] }
    return $v
}
function U64([byte[]]$b, [int]$o) {
    $v = [uint64]0
    for ($i = 7; $i -ge 0; $i--) { $v = ($v -shl 8) -bor $b[$o+$i] }
    return $v
}
function HexStr([byte[]]$b, [int]$n) {
    return (($b[0..($n-1)]) | ForEach-Object { $_.ToString('X2') }) -join ' '
}
function Dump-Dwords([byte[]]$b, [int]$n) {
    # every 4-byte-aligned dword, labeled by offset - lets the
    # kernel-read data location be found no matter the layout
    $parts = @()
    for ($o = 0; ($o + 4) -le $n; $o += 4) {
        $parts += ('@{0}={1}' -f $o, (U32 $b $o))
    }
    return $parts -join '  '
}
function Stat-Name([int]$s) {
    # 1 and 4 are field-confirmed (PONG status=1; step M expects 4).
    # The others follow the project convention - the NUMBER is authoritative.
    switch ($s) {
        0 { 'None' }
        1 { 'Success' }
        2 { 'ErrNotFound' }
        3 { 'ErrArgs' }
        4 { 'ErrAccess' }
        5 { 'ErrUnsupported' }
        default { "code-$s" }
    }
}
function Find-From([byte[]]$hay, [byte[]]$needle, [int]$start = 0) {
    # returns first offset >= start where needle matches, else -1
    if ($null -eq $hay) { return -1 }
    for ($i = $start; ($i + $needle.Length) -le $hay.Length; $i++) {
        $m = $true
        for ($j = 0; $j -lt $needle.Length; $j++) {
            if ($hay[$i + $j] -ne $needle[$j]) { $m = $false; break }
        }
        if ($m) { return $i }
    }
    return -1
}

function Read-EfiVar([string]$name, [byte[]]$buf) {
    $n = [EfiVarBridge]::GetFirmwareEnvironmentVariableW($name, $guid, $buf, [uint32]$buf.Length)
    $script:LastErr = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    return [int]$n
}

function Read-Infdiag([string]$Label) {
    $buf = New-Object byte[] 64
    $n = Read-EfiVar 'INFDIAG' $buf
    if ($n -le 0) {
        Write-Host "[$Label] INFDIAG read FAILED Win32=$LastErr"
        switch ($LastErr) {
            1314 { Write-Host "[$Label]   -> not elevated (run PowerShell as Administrator)" }
            2    { Write-Host "[$Label]   -> variable not found (RT driver not loaded this boot?)" }
            203  { Write-Host "[$Label]   -> variable not found (RT driver not loaded this boot?)" }
            87   { Write-Host "[$Label]   -> invalid parameter" }
        }
        return $null
    }
    Write-Host "[$Label] raw: $(HexStr $buf $n)"
    if ($n -ge 32 -and $buf[0] -eq 0x44 -and $buf[1] -eq 0x46 -and $buf[2] -eq 0x4E -and $buf[3] -eq 0x49) {
        $stage  = U32 $buf 4
        $flags  = U32 $buf 8
        $build  = U32 $buf 12
        $cr3    = U64 $buf 16
        $calls  = U32 $buf 24
        $lastst = U32 $buf 28
        $flagTxt = @()
        if ($flags -band 0x1)  { $flagTxt += 'loaded' }
        if ($flags -band 0x2)  { $flagTxt += 'EBS' }
        if ($flags -band 0x4)  { $flagTxt += 'virt' }
        if ($flags -band 0x8)  { $flagTxt += 'early-hooks' }
        if ($flags -band 0x20) { $flagTxt += 'TRIGGER-SEEN' }
        Write-Host ("[{0}] STAGE={1} flags=0x{2:X}({3}) win_build={4} os_cr3=0x{5:X} hook_calls={6} last_status=0x{7:X}" -f `
            $Label, $stage, $flags, ($flagTxt -join ','), $build, $cr3, $calls, $lastst)
        return [pscustomobject]@{ stage = $stage; flags = $flags; build = $build; calls = $calls; lastst = $lastst }
    }
    Write-Host "[$Label] magic mismatch - unexpected data"
    return $null
}

function Write-Var([string]$name, [byte[]]$data) {
    $ok = [EfiVarBridge]::SetFirmwareEnvironmentVariableExW($name, $guid, $data, [uint32]$data.Length, [uint32]$attrs)
    $err = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    if ($ok) { Write-Host "[OK] $name write accepted (Win32=0)" }
    else {
        Write-Host "[FAIL] $name write Win32=$err"
        switch ($err) {
            1314 { Write-Host '   -> not elevated' }
            87   { Write-Host '   -> invalid parameter (name/GUID/attrs)' }
            5    { Write-Host '   -> access denied' }
            203  { Write-Host '   -> not found' }
        }
    }
    return $ok
}

function Try-Del([string]$name) {
    # best-effort delete (size 0 + same attributes = EFI delete)
    try { $null = [EfiVarBridge]::SetFirmwareEnvironmentVariableExW($name, $guid, $null, [uint32]0, [uint32]$attrs) } catch { }
}

function Read-VarBack([string]$name) {
    # returns the trimmed byte array or $null; prints one line
    $buf = New-Object byte[] 64
    $n = Read-EfiVar $name $buf
    if ($n -gt 0) {
        Write-Host "[OK] $name read-back: $n bytes: $(HexStr $buf $n)"
        return ,$buf[0..($n-1)]
    }
    Write-Host "[--] $name read-back: ABSENT (Win32=$LastErr)"
    return $null
}

# ---- the v17-bug-free request builders ------------------------------
# THE v17 BUG: the helper below used a parameter literally named
# $pid. $PID is a read-only automatic PowerShell variable, so every
# call threw "Cannot overwrite variable pid..." and NO request was
# ever sent. All parameters here are deliberately named rseq / rop /
# rpid / rlen / raddr - none of them is an automatic variable.

function New-Req([object]$rseq, [object]$rop, [object]$rpid, [object]$rlen, [object]$raddr, [byte[]]$rdata) {
    # builds the 48-byte InfinityReq packet:
    #   [0..3]   sequence  u32
    #   [4..7]   op        u32
    #   [8..11]  pid       u32   (0 = any process, 0xFFFFFFFF = kernel target)
    #   [12..15] length    u32
    #   [16..23] address   u64   (hex STRING avoids every literal trap)
    #   [24..47] payload   24 bytes
    $req = New-Object byte[] 48
    [BitConverter]::GetBytes([uint32]$rseq).CopyTo($req, 0)
    [BitConverter]::GetBytes([uint32]$rop).CopyTo($req, 4)

    if ($null -eq $rpid)        { $p32 = [uint32]0 }
    elseif ($rpid -is [string]) { $p32 = [Convert]::ToUInt32($rpid, 16) }
    else                        { $p32 = [uint32]$rpid }
    [BitConverter]::GetBytes($p32).CopyTo($req, 8)

    if ($null -eq $rlen)        { $l32 = [uint32]0 }
    elseif ($rlen -is [string]) { $l32 = [Convert]::ToUInt32($rlen, 16) }
    else                        { $l32 = [uint32]$rlen }
    [BitConverter]::GetBytes($l32).CopyTo($req, 12)

    if ($null -eq $raddr)        { $a64 = [uint64]0 }
    elseif ($raddr -is [string]) { $a64 = [Convert]::ToUInt64($raddr, 16) }
    else                         { $a64 = [uint64]$raddr }
    [BitConverter]::GetBytes($a64).CopyTo($req, 16)

    if ($null -ne $rdata) {
        $cnt = [Math]::Min(24, $rdata.Length)
        for ($i = 0; $i -lt $cnt; $i++) { $req[24 + $i] = $rdata[$i] }
    }

    # belt and braces: the header must round-trip through the bytes
    # (plain -ne comparisons only - [int] casts would overflow on 0xFFFFFFFF,
    #  the same class of PS 5.1 trap as the v10 sign bug)
    if ((U32 $req 0) -ne [uint32]$rseq -or (U32 $req 4) -ne [uint32]$rop -or
        (U32 $req 8) -ne $p32 -or (U32 $req 12) -ne $l32 -or (U64 $req 16) -ne $a64) {
        throw 'request byte build failed (header mismatch)'
    }
    return ,$req
}

function Send-Req([byte[]]$ReqBytes) {
    # writes the request, polls for the matching response,
    # dumps EVERYTHING (resp raw + header + all dwords + InfinityData)
    $want = U32 $ReqBytes 0
    $null = Write-Var 'InfinityReq' $ReqBytes

    $resp = $null
    $seen = $null
    for ($try = 1; $try -le 12; $try++) {
        Start-Sleep -Milliseconds 100
        $rb = New-Object byte[] 64
        $rn = Read-EfiVar 'InfinityResp' $rb
        if ($rn -ge 32) {
            $seen = New-Object byte[] $rn
            [Array]::Copy($rb, $seen, $rn)
            if ((U32 $seen 0) -eq $want) { $resp = $seen; break }
        }
    }

    $status = -1
    $seqOk  = $false
    if ($null -ne $resp) {
        Write-Host "[OK] InfinityResp $($resp.Length) bytes: $(HexStr $resp $resp.Length)"
        $rseq  = U32 $resp 0
        $rstat = U32 $resp 4
        $rxfer = U32 $resp 8
        $raddr = U64 $resp 16
        $status = $rstat
        $seqOk  = ($rseq -eq $want)
        Write-Host ("     header: sequence=0x{0:X}  status={1}({2})  bytes_transferred={3}  out_address=0x{4:X}" -f `
            $rseq, $rstat, (Stat-Name $rstat), $rxfer, $raddr)
        Write-Host ('     resp dwords: ' + (Dump-Dwords $resp $resp.Length))
    } elseif ($null -ne $seen) {
        # a response exists but its sequence does not match - do NOT
        # use it as the answer; dump it so nothing hides
        Write-Host "[--] InfinityResp: only a STALE response (seq=0x$((U32 $seen 0).ToString('X')), wanted 0x$($want.ToString('X'))) - NOT used"
        Write-Host "[--] stale raw: $(HexStr $seen $seen.Length)"
        Write-Host ('     stale dwords: ' + (Dump-Dwords $seen $seen.Length))
    } else {
        Write-Host "[--] InfinityResp ABSENT after 12 tries (Win32=$LastErr)"
    }

    # the read data may also land in the InfinityData buffer - dump it too
    $dataBytes = $null
    $db = New-Object byte[] 64
    $dn = Read-EfiVar 'InfinityData' $db
    if ($dn -gt 0) {
        Write-Host "[DT] InfinityData $dn bytes: $(HexStr $db $dn)"
        Write-Host ('     data dwords: ' + (Dump-Dwords $db $dn))
        $dataBytes = New-Object byte[] $dn
        [Array]::Copy($db, $dataBytes, $dn)
    } else {
        Write-Host "[DT] InfinityData absent (Win32=$LastErr)"
    }

    Try-Del 'InfinityResp'
    return [pscustomobject]@{ Resp = $resp; SeqOk = $seqOk; Status = $status; Data = $dataBytes }
}

# ============================================================
# [0] find a writable spot + start the transcript
#      (the boot stick is READ-ONLY by design, so the output
#       lands on a writable drive - Desktop)
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$cands = @()
try { $cands += (Get-Location).ProviderPath } catch { }
try { $cands += [Environment]::GetFolderPath('Desktop') } catch { }
$cands += 'C:\Users\Administrator\Desktop'
$spot = $null
foreach ($c in $cands) {
    if (-not $c) { continue }
    try {
        $t = Join-Path $c ('.wr-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        [IO.File]::WriteAllText($t, 'x')
        [IO.File]::Delete($t)
        $spot = $c
        break
    } catch { }
}
$transPath = $null
if ($spot) {
    $transPath = Join-Path $spot ("trigger-test-v20-output-$stamp.txt")
    try { Start-Transcript -Path $transPath | Out-Null }
    catch { $transPath = $null }
}
if ($transPath) {
    Write-Host '[LOG] writable spot found - auto-saving all output to:'
    Write-Host "[LOG] $transPath"
    Write-Host '[LOG] (the folder beside the script is READ-ONLY - the boot'
    Write-Host '[LOG]  stick is read-only by design - so the transcript lands'
    Write-Host '[LOG]  on a writable drive instead. Get it out of the VM with'
    Write-Host '[LOG]  the transfer stick + refresh-files.bat - see the end.)'
} else {
    Write-Host '[LOG] no writable spot found - photograph this window instead.'
}

Write-Host ''
Write-Host '==== INFINITY trigger test v20 (v19 VM-crash root-caused: attach op dropped, kernel reads first) ===='
Write-Host ("[ENV] PowerShell $($PSVersionTable.PSVersion)  Windows build $([Environment]::OSVersion.Version.ToString())")

# ============================================================
# [-1] PARSER SELF-TEST (new in v19): the v18 run burned a whole
#      test cycle because U32 silently truncated every dword to
#      its low byte and nothing caught it before the driver was
#      touched. Never again: prove every parser/helper on known
#      patterns FIRST, abort loudly on any mismatch.
$st_t = New-Object byte[] 4
$st_t[0] = 0x37; $st_t[1] = 0x13; $st_t[2] = 0x00; $st_t[3] = 0x00   # 0x1337
if ((U32 $st_t 0) -ne 0x1337) {
    Write-Host "[SELFTEST][ABORT] U32(37 13 00 00)=$((U32 $st_t 0)) but expected 0x1337 - do not run the test, send this .txt"
    exit 1
}
$st_t[0] = 0x65; $st_t[1] = 0x4A                                       # 0x4A65 = 19045
if ((U32 $st_t 0) -ne 19045) {
    Write-Host "[SELFTEST][ABORT] U32(65 4A 00 00)=$((U32 $st_t 0)) but expected 19045 - do not run the test, send this .txt"
    exit 1
}
$st_t[0] = 0xFF; $st_t[1] = 0xFF; $st_t[2] = 0xFF; $st_t[3] = 0xFF    # kernel pid
if ((U32 $st_t 0) -ne [Convert]::ToUInt32('FFFFFFFF', 16)) {
    # v20 fix: the v19 form '[uint32]0xFFFFFFFF' hit PS 5.1 trap #4 -
    # hex literals 0x80000000..0xFFFFFFFF parse as NEGATIVE Int32, and
    # [uint32](-1) throws (seen live in the v19 run's transcript)
    Write-Host "[SELFTEST][ABORT] U32(FF FF FF FF)=$((U32 $st_t 0)) but expected 0xFFFFFFFF - do not run the test, send this .txt"
    exit 1
}
$st_u = New-Object byte[] 8
$st_u[0] = 0x00; $st_u[1] = 0x10; $st_u[2] = 0xC0; $st_u[3] = 0x7F    # os_cr3 pattern
if ((U64 $st_u 0) -ne 0x7FC01000) {
    Write-Host "[SELFTEST][ABORT] U64(00 10 C0 7F 00 00 00 00) gave 0x$((U64 $st_u 0).ToString('X')) but expected 0x7FC01000 - do not run the test, send this .txt"
    exit 1
}
$st_hb = HexLe4 'DEADBEEF'
if ($st_hb[0] -ne 0xEF -or $st_hb[1] -ne 0xBE -or $st_hb[2] -ne 0xAD -or $st_hb[3] -ne 0xDE) {
    Write-Host '[SELFTEST][ABORT] HexLe4 DEADBEEF bytes wrong - do not run the test, send this .txt'
    exit 1
}
$st_req = $null
try { $st_req = New-Req 0x1999 1 'FFFFFFFF' 4 '0000800000000000' $null }
catch { Write-Host "[SELFTEST][ABORT] New-Req threw: $($_.Exception.Message) - do not run the test, send this .txt"; exit 1 }
if ($null -eq $st_req -or $st_req.Length -ne 48) {
    Write-Host '[SELFTEST][ABORT] New-Req returned no 48-byte packet - do not run the test, send this .txt'
    exit 1
}
if ($st_req[0] -ne 0x99 -or $st_req[1] -ne 0x19 -or $st_req[4] -ne 0x01) {
    Write-Host '[SELFTEST][ABORT] New-Req seq/op bytes wrong - do not run the test, send this .txt'
    exit 1
}
if (-not ($st_req[8] -eq 0xFF -and $st_req[9] -eq 0xFF -and $st_req[10] -eq 0xFF -and $st_req[11] -eq 0xFF)) {
    Write-Host '[SELFTEST][ABORT] New-Req pid bytes wrong (expected FF FF FF FF) - do not run the test, send this .txt'
    exit 1
}
if ($st_req[12] -ne 0x04) {
    Write-Host '[SELFTEST][ABORT] New-Req len byte wrong (expected 04) - do not run the test, send this .txt'
    exit 1
}
if (-not ($st_req[16] -eq 0x00 -and $st_req[17] -eq 0x00 -and $st_req[18] -eq 0x00 -and $st_req[19] -eq 0x00 -and $st_req[20] -eq 0x00 -and $st_req[21] -eq 0x80 -and $st_req[22] -eq 0x00 -and $st_req[23] -eq 0x00)) {
    Write-Host '[SELFTEST][ABORT] New-Req addr bytes wrong (expected 00 00 00 00 00 80 00 00) - do not run the test, send this .txt'
    exit 1
}
Write-Host '[SELFTEST] U32/U64/HexLe4/New-Req all passed - parsers verified before touching the driver'

# [1] privilege
$rc = [EfiVarBridge]::EnablePriv('SeSystemEnvironmentPrivilege')
if (-not $rc) {
    Write-Host '[ABORT] SeSystemEnvironmentPrivilege failed - run PowerShell as Administrator.'
    exit 1
}
Write-Host '[OK] SeSystemEnvironmentPrivilege enabled (rc=0)'

# [2] cleanup stale probe variables from earlier runs (best-effort)
Try-Del 'INFPROBE'
Try-Del 'INFTRIGGER'
Try-Del 'InfinityReq'
Try-Del 'InfinityResp'
Try-Del 'InfinityData'
Start-Sleep -Milliseconds 200
Write-Host '[CLR] stale probe variables cleaned (best effort)'

# [3] baseline reads: A then B (no writes in between)
Write-Host ''
Write-Host '--- step A/B: baseline INFDIAG double read (read path via hook?) ---'
Write-Host '       v20: reads are answered LIVE from RAM by the hook (the'
Write-Host '       bridge is field-proven since v15), so B must be A+1 or'
Write-Host '       more if the read path works.'
$A = Read-Infdiag 'A'
Start-Sleep -Milliseconds 250
$B = Read-Infdiag 'B'
if ($null -eq $A -or $null -eq $B) {
    Write-Host '[ABORT] INFDIAG unreadable - is the RT driver (usb-d) the one that booted?'
    exit 1
}

# [4] neutral write probe: INFPROBE (not a driver name - pure raw NVRAM write)
Write-Host ''
Write-Host '--- step C: INFPROBE write (neutral name; raw NVRAM write path) ---'
$payload = New-Object byte[] 1
$payload[0] = 0x42
$null = Write-Var 'INFPROBE' $payload
Start-Sleep -Milliseconds 250
$C = Read-Infdiag 'C'
$probeBack = Read-VarBack 'INFPROBE'

# [5] driver trigger variable (first INFCNT increment)
Write-Host ''
Write-Host '--- step D: INFTRIGGER write (trigger flag 0x20 + INFCNT +1) ---'
$payload[0] = 0x42
$null = Write-Var 'INFTRIGGER' $payload
Start-Sleep -Milliseconds 250
$D = Read-Infdiag 'D'

# [6] the real PING
Write-Host ''
Write-Host '--- step E: InfinityReq PING (48 bytes, op=0xDEADBEEF) ---'
$req = New-Object byte[] 48
[BitConverter]::GetBytes([uint32]0x1337).CopyTo($req, 0)   # sequence (small literal: safe)
$opBytes = HexLe4 'DEADBEEF'
$opBytes.CopyTo($req, 4)                                    # op = PING
if ($req[0] -ne 0x37 -or $req[1] -ne 0x13 -or $req[4] -ne 0xEF -or $req[5] -ne 0xBE -or $req[6] -ne 0xAD -or $req[7] -ne 0xDE) {
    Write-Host '[ABORT] packet bytes wrong - refusing to send a broken ping. Send the output .txt.'
    exit 1
}
Write-Host "       req bytes[0..7]: $(HexStr $req 8)  (37 13 00 00 EF BE AD DE expected)"
$null = Write-Var 'InfinityReq' $req
Start-Sleep -Milliseconds 400
$E = Read-Infdiag 'E'   # also gives the driver a foreign call to process the ping

Write-Host ''
Write-Host '--- step E2: reading InfinityResp (FULL BRIDGE check) ---'
$rbuf = New-Object byte[] 64
$rn = Read-EfiVar 'InfinityResp' $rbuf
$respAnswered = $false
$respTxt = 'ABSENT'
if ($rn -ge 32) {
    Write-Host "[OK] InfinityResp $rn bytes: $(HexStr $rbuf $rn)"
    $rseq  = U32 $rbuf 0
    $rstat = U32 $rbuf 4
    $rxfer = U32 $rbuf 8
    $raddr = U64 $rbuf 16
    Write-Host ("     sequence=0x{0:X}  status={1}({2})  bytes_transferred={3}  out_address=0x{4:X}" -f `
        $rseq, $rstat, (Stat-Name $rstat), $rxfer, $raddr)
    if ($rseq -eq 0x1337 -and $rstat -eq 1) {
        $respAnswered = $true
        $respTxt = 'ANSWERED seq=0x1337 status=1(Success) - PONG PERFECT'
    } else {
        $respTxt = "WRONG-CONTENT seq=0x$($rseq.ToString('X')) status=$rstat"
    }
} else {
    Write-Host "[--] InfinityResp ABSENT (Win32=$LastErr; 203 = not found)"
}
Try-Del 'InfinityResp'   # clear the PONG so steps I..M cannot read it as stale

# [7] final state + read-backs
Write-Host ''
Write-Host '--- step F: final INFDIAG + InfinityReq read-back ---'
$F = Read-Infdiag 'F'
$reqBack = Read-VarBack 'InfinityReq'
$reqAbsent = ($null -eq $reqBack)

# [8] INFCNT - the bypass-safe write-path proof
Write-Host ''
Write-Host '--- step G: INFCNT read (live RAM count: 0 = writes bypassed, 2 = both reached) ---'
$cntBack = Read-VarBack 'INFCNT'
$cntVal = -1
if ($null -ne $cntBack -and $cntBack.Length -ge 4) { $cntVal = U32 $cntBack 0 }

# [9] step H: InfinityData write+read round trip (the payload transport)
Write-Host ''
Write-Host '--- step H: InfinityData write+read round trip (the payload transport) ---'
$hd = New-Object byte[] 32
[BitConverter]::GetBytes([uint32]0x1447).CopyTo($hd, 0)    # step H sequence
$v = 0x27
for ($i = 4; $i -lt 32; $i++) { $hd[$i] = [byte]$v; $v += 7 }
if ($hd[4] -ne 0x27 -or $hd[31] -ne 0xE4) {
    Write-Host '[ABORT] H pattern bytes wrong - refusing to send. Send the output .txt.'
    exit 1
}
$null = Write-Var 'InfinityData' $hd
Start-Sleep -Milliseconds 300
$hBack = Read-VarBack 'InfinityData'
$hExact = $false
if ($null -ne $hBack -and $hBack.Length -eq 32) {
    $hExact = $true
    for ($i = 0; $i -lt 32; $i++) { if ($hBack[$i] -ne $hd[$i]) { $hExact = $false; break } }
}
if ($hExact) { Write-Host '     32-byte pattern echoed back byte-exact: YES - payload transport WORKS' }
else         { Write-Host '     32-byte pattern echoed back byte-exact: NO - see raw above' }

# [10] step I: ReqOp_Attach -- SKIPPED IN v20 (VM-FATAL, disassembly-proven)
# The v19 run crashed the whole VM exactly here. Disassembly of the v17
# driver binary (recovered from the GitHub vault history) shows op=7 makes
# ProcessFinder::FindByName walk the Windows process list looking for
# emulator processes (aow_exe.exe / AndroidProcess.exe / LdVBoxHeadless.exe /
# HD-Player.exe - BlueStacks/Nox/LDPlayer targets). None exist in this plain
# Windows VM, and that walk faults in firmware context -> triple fault ->
# QEMU dies. Attachment is NOT needed for the kernel-target reads below
# (pid=FFFFFFFF uses the current-CR3 page walk directly), so step I is
# dropped and steps J..M now run FIRST.
Write-Host ''
Write-Host '--- step I: ReqOp_Attach -- SKIPPED (v19 crashed the VM here; op=7 walks the'
Write-Host '     process list for emulator EXEs that do not exist in this VM -'
Write-Host '     disassembly-proven fatal, and NOT needed for kernel reads) ---'
$attachTxt = 'SKIPPED in v20 (VM-fatal in v19 run: op=7 attach walks EPROCESS for emulator processes; kernel reads below do not need it)'

# [11] step J: kernel read KUSD+0x260 x4 (pid=FFFFFFFF = KERNEL target)
Write-Host ''
Write-Host '--- step J: kernel read KUSD+0x260 x4  (pid=FFFFFFFF = KERNEL target) ---'
$J = $null
try { $J = Send-Req (New-Req 0x1666 1 'FFFFFFFF' 4 'FFFFF78000000260' $null) }
catch { Write-Host "[!] step J threw: $($_.Exception.Message)" }
$expBuild = New-Object byte[] 4
$expBuild[0] = 0x65; $expBuild[1] = 0x4A; $expBuild[2] = 0x00; $expBuild[3] = 0x00   # 19045 = 0x4A65 LE
$jVal = -1
$jWhere = 'NOWHERE'
if ($null -ne $J -and $null -ne $J.Resp) {
    $o = Find-From $J.Resp $expBuild 8          # data cannot live in seq/status
    if ($o -ge 8) { $jVal = U32 $J.Resp $o; $jWhere = "InfinityResp offset $o" }
}
if ($jVal -lt 0 -and $null -ne $J -and $null -ne $J.Data) {
    $o = Find-From $J.Data $expBuild 0
    if ($o -ge 0) { $jVal = U32 $J.Data $o; $jWhere = "InfinityData offset $o" }
}
if ($jVal -eq 19045) {
    Write-Host ("     KUSD build dword VIA THE BRIDGE = {0} (0x{1:X}) at {2}  (expected 19045 = 0x4A65) - MATCH" -f $jVal, $jVal, $jWhere)
    $jTxt = "PROVEN - 19045 found at $jWhere"
} elseif ($jVal -ge 0) {
    Write-Host ("     KUSD build dword VIA THE BRIDGE = {0} (0x{1:X}) at {2}  (expected 19045) - MISMATCH, see dwords above" -f $jVal, $jVal, $jWhere)
    $jTxt = "ANSWERED but wrong value $jVal at $jWhere - see serial [RD] lines"
} elseif ($null -ne $J -and $null -ne $J.Resp) {
    Write-Host '     KUSD build dword VIA THE BRIDGE = NOT FOUND in resp or InfinityData (script-side truth: 19045)'
    $jTxt = "ANSWERED status=$($J.Status)($(Stat-Name $J.Status)) but no 0x4A65 in the payload - see serial [RD] lines"
} else {
    Write-Host '     KUSD build dword VIA THE BRIDGE = NO RESPONSE'
    $jTxt = 'NO RESPONSE - see serial'
}
if ($jVal -lt 0) { $jVal = -1 }

# [12] step K: kernel read KUSD+0x308 x4 (v15/v16 field truth: 0)
Write-Host ''
Write-Host '--- step K: kernel read KUSD+0x308 x4  (v15/v16 field truth: 0) ---'
$K = $null
try { $K = Send-Req (New-Req 0x1777 1 'FFFFFFFF' 4 'FFFFF78000000308' $null) }
catch { Write-Host "[!] step K threw: $($_.Exception.Message)" }
$kVal = -1
$kTxt = 'UNKNOWN - cannot localize the data offset (J did not find it); see dwords above'
if ($null -ne $K -and $jWhere -ne 'NOWHERE') {
    $off = [int]($jWhere -replace '[^0-9]', '')
    $srcArr = $null
    if ($jWhere.StartsWith('InfinityResp') -and $null -ne $K.Resp) { $srcArr = $K.Resp }
    if ($jWhere.StartsWith('InfinityData') -and $null -ne $K.Data) { $srcArr = $K.Data }
    if ($null -ne $srcArr -and ($off + 4) -le $srcArr.Length) {
        $kVal = U32 $srcArr $off
        $kTxt = "value at $jWhere = $kVal  (expected 0)"
        if ($kVal -eq 0 -and $K.SeqOk -and $K.Status -eq 1) { $kTxt += ' - CONSISTENT' }
    }
}
Write-Host "     KUSD+0x308 dword = $kVal   ($kTxt)"

# [13] step L: kernel read KUSD+0x260 x8 (chunk test; dword[0] must equal J)
Write-Host ''
Write-Host '--- step L: kernel read KUSD+0x260 x8  (chunk test; dword[0] must equal J) ---'
$L = $null
try { $L = Send-Req (New-Req 0x1888 1 'FFFFFFFF' 8 'FFFFF78000000260' $null) }
catch { Write-Host "[!] step L threw: $($_.Exception.Message)" }
if ($null -ne $L -and $jWhere -ne 'NOWHERE') {
    $off = [int]($jWhere -replace '[^0-9]', '')
    $srcArr = $null
    if ($jWhere.StartsWith('InfinityResp') -and $null -ne $L.Resp) { $srcArr = $L.Resp }
    if ($jWhere.StartsWith('InfinityData') -and $null -ne $L.Data) { $srcArr = $L.Data }
    if ($null -ne $srcArr -and ($off + 8) -le $srcArr.Length) {
        $d0 = U32 $srcArr $off
        $d1 = U32 $srcArr ($off + 4)
        $cons = ($d0 -eq $jVal)
        Write-Host ("     dword[0]={0}  dword[1]={1}  consistent with J: {2}" -f $d0, $d1, $(if ($cons) {'YES'} else {'NO'}))
    } else {
        Write-Host '     data offset not available in this response - see dwords above'
    }
} else {
    Write-Host '     cannot cross-check with J (J found nothing) - see dwords above'
}

# [14] step M: kernel read NON-CANONICAL VA (expect ErrAccess(4), NO crash)
Write-Host ''
Write-Host '--- step M: kernel read NON-CANONICAL VA (expect ErrAccess(4), NO crash) ---'
$M = $null
try { $M = Send-Req (New-Req 0x1999 1 'FFFFFFFF' 4 '0000800000000000' $null) }
catch { Write-Host "[!] step M threw: $($_.Exception.Message)" }
$mTxt = 'NO RESPONSE'
if ($null -ne $M -and $null -ne $M.Resp) {
    if ($M.Status -eq 4) { $mTxt = 'OK - status=4(ErrAccess) as designed; script still alive = no crash' }
    else { $mTxt = "UNEXPECTED status=$($M.Status)($(Stat-Name $M.Status)) - see serial" }
}
Write-Host "     negative-VA handling: $mTxt"

# [15] step N: final INFCNT (expect G+1 - only InfinityData persists)
Write-Host ''
Write-Host '--- step N: final INFCNT read (live RAM count; expect G+1: only InfinityData persists) ---'
$nBack = Read-VarBack 'INFCNT'
$cntFinal = -1
if ($null -ne $nBack -and $nBack.Length -ge 4) { $cntFinal = U32 $nBack 0 }

# ============================================================
# summary (null-safe: -1 means that read failed)
function NCalls($x) { if ($null -ne $x) { return [int]$x.calls } else { return -1 } }
$cA = NCalls $A; $cB = NCalls $B; $cC = NCalls $C
$cD = NCalls $D; $cE = NCalls $E; $cF = NCalls $F
$fStage = -1; $fFlags = 0; $fBuild = -1
if ($null -ne $F) { $fStage = $F.stage; $fFlags = $F.flags; $fBuild = $F.build }
$winBuildOs = [Environment]::OSVersion.Version.Build
$buildEq = ($fBuild -ge 0 -and $fBuild -eq $winBuildOs)

$readOk   = (($cB - $cA) -ge 1)
$writeOk  = ($cntVal -ge 2) -or ((($fFlags -band 0x20) -ne 0) -and ($cntVal -ge 1))
$trigSet  = ($fFlags -band 0x20) -ne 0
$probeFound = ($null -ne $probeBack)

Write-Host ''
Write-Host '==== SUMMARY (auto-saved to the output .txt) ===='
Write-Host ("hook_calls  A={0} B={1} C={2} D={3} E={4} F={5}" -f $cA, $cB, $cC, $cD, $cE, $cF)
Write-Host ("stage F={0}  flags F=0x{1:X}  trigger_seen(0x20)={2}" -f $fStage, $fFlags, $(if ($trigSet) {'SET'} else {'NOT-SET'}))
Write-Host ("win_build  driver-live={0}  script-side={1}   ({2})" -f $fBuild, $winBuildOs, $(if ($buildEq) {'EQUAL - build detection works'} else {'MISMATCH - see INFDIAG raw + serial'}))
Write-Host ("INFCNT live RAM count (our-var writes that reached the hook) = {0}   (0 = bypassed, 2 = both)" -f $cntVal)
Write-Host ("[1] GetVariable path via hook : {0}" -f $(if ($readOk) {'PROVEN (hook_calls moves between reads)'} else {'BYPASSED (counts frozen - kernel reads NVRAM directly)'}))
Write-Host ("[2] SetVariable path via hook : {0}" -f $(if ($writeOk) {"PROVEN (INFCNT=$cntVal, flag 0x20)"} else {'BYPASSED (writes land in NVRAM but never touch the hook)'}))
Write-Host ("[3] INFPROBE landed in NVRAM  : {0}" -f $(if ($probeFound) {'YES (raw firmware write path works)'} else {'NO (write returned OK but variable absent!)'}))
Write-Host ("[4] InfinityReq consumed (RAM) : {0}" -f $(if ($respAnswered) {'YES (PONG proves it)'} else {'UNPROVEN (no PONG this run)'}))
if ($reqAbsent -and $respAnswered) { Write-Host '    NVRAM read-back: absent - ABSENT is EXPECTED (v13+ consumes it in RAM)' }
Write-Host ("[5] InfinityResp PING         : {0}" -f $respTxt)
Write-Host ("[6] InfinityData buffer round trip : {0}" -f $(if ($hExact) {'BYTE-EXACT (payload transport works)'} else {'FAILED - see step H raw bytes'}))
Write-Host ("[7] ReqOp_Attach (op=7)         : {0}" -f $attachTxt)
Write-Host ("[8] Kernel read KUSD+0x260 (J)     : {0}" -f $jTxt)
Write-Host ("[9] Negative VA handling (M)       : {0}" -f $mTxt)
Write-Host ("    INFCNT final = {0}   (expect G+1 = {1}: only the InfinityData write persists;" -f $cntFinal, $(if ($cntVal -ge 0) { $cntVal + 1 } else { '?' }))
Write-Host '     request writes are consumed in RAM and never count - v17 said "expect 8", that was wrong)'

Write-Host ''
Write-Host 'VERDICT:'
$kernOk = ($jVal -eq 19045)
$bridgeOk = $respAnswered -and $hExact
if ($kernOk) {
    Write-Host '>>> KERNEL DATA PATH PROVEN - PHASE E COMPLETE <<<'
    Write-Host 'Windows -> InfinityReq -> our hook -> kernel read -> InfinityResp.'
    if (-not ($null -ne $M -and $M.Status -eq 4)) {
        Write-Host 'NOTE: step M did not return ErrAccess(4) - check [9] and the serial log.'
    }
} elseif ($bridgeOk) {
    Write-Host '>>> FULL BRIDGE PROVEN (v16/v17 result) - but the data path'
    Write-Host '>>> did not return the expected dword. <<<'
    Write-Host 'The requests WERE sent this time (no v17 script crash). The serial'
    Write-Host 'log has the [RD] kern va / kern read ok lines - send output .txt +'
    Write-Host 'serial-phase-d.log.'
} else {
    Write-Host '>>> BRIDGE REGRESSION vs v17 (PING or payload transport failed). <<<'
    Write-Host 'Send output .txt + serial-phase-d.log.'
}
Write-Host '==== END v20 ===='

if ($transPath) {
    $saved = $false
    try {
        $fi = Get-Item -LiteralPath $transPath -ErrorAction Stop
        if ($fi.Length -gt 1024) { $saved = $true }
    } catch { }
    if ($saved) { Write-Host "[LOG] output saved and VERIFIED: $transPath" }
    else        { Write-Host "[LOG] output file problem: $transPath (photograph this window too)" }
    Write-Host '[LOG] HOW TO GET THE .TXT OUT of the VM (no photos needed):'
    Write-Host '[LOG]   1. on YOUR machine: put any file for the VM into the'
    Write-Host '[LOG]      transfer folder and double-click refresh-files.bat'
    Write-Host '[LOG]      - a USB stick appears inside Windows'
    Write-Host '[LOG]   2. inside Windows: copy the .txt onto that stick'
    Write-Host '[LOG]   3. on YOUR machine: run refresh-files.bat again - the'
    Write-Host '[LOG]      file lands in the transfer folder. Send that file.'
    try { Stop-Transcript | Out-Null } catch { }
}
