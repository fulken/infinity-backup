# ============================================================
# INFINITY trigger test v17  (run INSIDE the Windows VM,
# in an ELEVATED PowerShell: "Run as Administrator")
#
# REQUIRES the v17 driver (infinity-qemu-test-v17 package).
# Running it against v9..v16 drivers gives WRONG verdicts on the
# data steps - check that phase-d.bat printed "package v17" and
# the boot log says "memory.efi v17 RT".
#
# What v17 adds on top of the PROVEN bridge (the v16 field run
# printed ">>> FULL BRIDGE PROVEN - PHASE D COMPLETE <<<"):
#   - THE DATA PATH: steps H..N replicate exactly what the real
#     client (Infinity.exe) does for process memory - a 48-byte
#     InfinityReq {sequence, op, pid, data_size, address} -> the
#     driver page-walks the address and the payload comes back
#     through InfinityResp (status + bytes) + InfinityData (the
#     bytes themselves). J reads the Windows build dword straight
#     out of KUSER_SHARED_DATA (+0x260) THROUGH THE BRIDGE and it
#     must equal the script-side build (19045 on this VM).
#   - pid=0xFFFFFFFF (KERNEL_TARGET_PID, new in the v17 driver)
#     selects the kernel target: the read is served from the
#     CALLER's address space. A bad VA (step M) fails the page
#     walk cleanly - ErrAccess, never a crash.
#   - AUTO-TEE FIX: the boot stick (D:) is READ-ONLY by design,
#     so the transcript now lands on the first WRITABLE location
#     (beside script -> Desktop -> TEMP) and is VERIFIED at the
#     end. How to get it out: transfer stick + refresh-files.bat.
#
# Step map:
#   A,B  INFDIAG reads          -> hook_calls must MOVE (read path)
#   C    INFPROBE write+read    -> raw NVRAM write path
#   D    INFTRIGGER write       -> trigger flag + INFCNT +1 (write path)
#   E    InfinityReq PING       -> the real request
#   E2   InfinityResp read      -> FULL BRIDGE check
#   F    final INFDIAG + read-backs
#   G    INFCNT read            -> live write-path count, RAM-served
#   H    InfinityData round trip-> payload transport (byte-exact)
#   I    ReqOp_Attach           -> expect ErrNotFound on clean VM
#   J    kernel read KUSD+0x260 -> THE data path (expect 19045)
#   K    kernel read KUSD+0x308 -> field truth says 0
#   L    kernel read x8 (chunk) -> dword[0] must equal J
#   M    negative VA read       -> expect ErrAccess(4), no crash
#   N    final INFCNT           -> expect 8 (2 baseline + 6 new)
#
# Win32 203 = ERROR_ENVVAR_NOT_FOUND (normal "variable absent").
# stage=4 is EXPECTED (armed; live RAM state from the first read).
# status=1 (Success) on InfinityResp is the CORRECT PONG status.
# ============================================================

$ErrorActionPreference = 'Continue'

# ---- v17: auto-tee with a WRITABLE-location fallback -------------
# The v16 run found the trap: this script usually lives on the boot
# stick (D:), and phase-d.bat attaches that stick READ-ONLY on
# purpose (the 2026-09-20 FAT-corruption lesson). "Save beside the
# script" can never work there. v17 probes each candidate folder
# (beside script -> Desktop -> TEMP), uses the first WRITABLE one,
# and VERIFIES the file at the end.
$__teeOk = $false
$__log   = $null
$__logNote = ''
$__cands = @()
if ($PSScriptRoot) { $__cands += $PSScriptRoot }
try { $d = [Environment]::GetFolderPath('Desktop'); if ($d) { $__cands += $d } } catch { }
if ($env:TEMP) { $__cands += $env:TEMP }
foreach ($__d in $__cands) {
    $__probe = Join-Path $__d ("infinity-v17-probe-{0}.tmp" -f $PID)
    try {
        [System.IO.File]::WriteAllText($__probe, 'x')
        Remove-Item -LiteralPath $__probe -Force -ErrorAction SilentlyContinue
    } catch { continue }
    $__log = Join-Path $__d ("trigger-test-v17-output-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    try {
        Start-Transcript -Path $__log -ErrorAction Stop | Out-Null
        $__teeOk = $true
    } catch { $__teeOk = $false }
    if ($__teeOk) {
        Write-Host '[LOG] writable spot found - auto-saving all output to:'
        Write-Host "[LOG] $__log"
        if ($PSScriptRoot -and ($__d -ne $PSScriptRoot)) {
            Write-Host '[LOG] (the folder beside the script is READ-ONLY - the boot'
            Write-Host '[LOG]  stick is read-only by design - so the transcript lands'
            Write-Host '[LOG]  on a writable drive instead. Get it out of the VM with'
            Write-Host '[LOG]  the transfer stick + refresh-files.bat - see the end.)'
        }
        break
    }
}
if (-not $__teeOk) {
    Write-Host '[LOG] transcript unavailable - photo the screen as before'
}

function __Finish([int]$code) {
    if ($__teeOk) {
        try { Stop-Transcript | Out-Null } catch { }
    }
    exit $code
}

$src = @'
using System;
using System.Runtime.InteropServices;

public static class EfiVarBridge {
    // ---- privilege enabling (struct fix from v7)
    [StructLayout(LayoutKind.Sequential)]
    public struct LUID { public uint LowPart; public int HighPart; }

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID_AND_ATTRIBUTES {
        public LUID Luid;
        public uint Attributes;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES {
        public uint PrivilegeCount;
        public LUID_AND_ATTRIBUTES Privileges;
    }

    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

    [DllImport("kernel32.dll")]
    static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out LUID lpLuid);

    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool AdjustTokenPrivileges(IntPtr TokenHandle, bool DisableAllPrivileges,
        ref TOKEN_PRIVILEGES NewState, uint BufferLength, IntPtr PreviousState, IntPtr ReturnLength);

    // ---- firmware variable APIs (v7 correct parameter order)
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern uint GetFirmwareEnvironmentVariableW(
        string lpName, string lpGuid, byte[] pBuffer, uint nSize);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool SetFirmwareEnvironmentVariableExW(
        string lpName, string lpGuid, byte[] pValue, uint nSize, uint dwAttributes);

    public static bool EnablePriv(string name) {
        IntPtr token;
        if (!OpenProcessToken(GetCurrentProcess(), 0x28, out token))
            return false;
        LUID luid;
        if (!LookupPrivilegeValue(null, name, out luid))
            return false;
        TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
        tp.PrivilegeCount = 1;
        tp.Privileges.Luid = luid;
        tp.Privileges.Attributes = 2;   // SE_PRIVILEGE_ENABLED
        return AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
    }
}
'@

if (-not ("EfiVarBridge" -as [type])) {
    try { Add-Type -TypeDefinition $src -Language CSharp }
    catch {
        Write-Host '[ABORT] Add-Type failed (unexpected). Send the output .txt or a photo.'
        Write-Host $_.Exception.Message
        __Finish 1
    }
}

# ---- constants ------------------------------------------------------
$guid  = '{A1B2C3D4-E5F6-4789-9ABC-DEF012345678}'
$attrs = 0x7    # EFI_VARIABLE_NON_VOLATILE | BOOTSERVICE | RUNTIME

# ---- helpers --------------------------------------------------------
function HexLe4([string]$hex) {
    # 'DEADBEEF' -> bytes EF BE AD DE (little endian), from hex STRING
    # (PowerShell hex-literal sign trap = the v10 bug, never again).
    $h = $hex.PadLeft(8, '0')
    $b = New-Object byte[] 4
    for ($i = 0; $i -lt 4; $i++) {
        $b[$i] = [Convert]::ToByte($h.Substring(6 - 2 * $i, 2), 16)
    }
    return $b
}

function U32([byte[]]$b, [int]$o) {
    # v16 fix: PowerShell -shl on a BYTE returns a BYTE - the v15
    # parser truncated every dword to its low byte (19045 -> "101",
    # 0x1337 -> "0x37"). Plain [uint32] math, no shift operators.
    return ([uint32]$b[$o]) + ([uint32]$b[$o+1] * 256) + ([uint32]$b[$o+2] * 65536) + ([uint32]$b[$o+3] * 16777216)
}
function U64([byte[]]$b, [int]$o) {
    $v = [uint64]0
    for ($i = 7; $i -ge 0; $i--) { $v = ($v -shl 8) -bor $b[$o+$i] }
    return $v
}
function HexStr([byte[]]$b, [int]$n) {
    return (($b[0..($n-1)]) | ForEach-Object { $_.ToString('X2') }) -join ' '
}

function Read-EfiVar([string]$name, [byte[]]$buf) {
    $n = [EfiVarBridge]::GetFirmwareEnvironmentVariableW($name, $guid, $buf, [uint32]$buf.Length)
    $script:LastErr = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    return [int]$n
}

function Read-Infdiag([string]$Label) {
    $buf = New-Object byte[] 64
    $n = Read-EfiVar 'INFDIAG' $buf
    if ($n -le 0) {
        Write-Host "[$Label] INFDIAG read FAILED Win32=$LastErr"
        switch ($LastErr) {
            1314 { Write-Host "[$Label]   -> not elevated (run PowerShell as Administrator)" }
            2    { Write-Host "[$Label]   -> variable not found (RT driver not loaded this boot?)" }
            203  { Write-Host "[$Label]   -> variable not found (RT driver not loaded this boot?)" }
            87   { Write-Host "[$Label]   -> invalid parameter" }
        }
        return $null
    }
    Write-Host "[$Label] raw: $(HexStr $buf $n)"
    if ($n -ge 32 -and $buf[0] -eq 0x44 -and $buf[1] -eq 0x46 -and $buf[2] -eq 0x4E -and $buf[3] -eq 0x49) {
        $stage  = U32 $buf 4
        $flags  = U32 $buf 8
        $build  = U32 $buf 12
        $cr3    = U64 $buf 16
        $calls  = U32 $buf 24
        $lastst = U32 $buf 28
        $flagTxt = @()
        if ($flags -band 0x1)  { $flagTxt += 'loaded' }
        if ($flags -band 0x2)  { $flagTxt += 'EBS' }
        if ($flags -band 0x4)  { $flagTxt += 'virt' }
        if ($flags -band 0x8)  { $flagTxt += 'early-hooks' }
        if ($flags -band 0x20) { $flagTxt += 'TRIGGER-SEEN' }
        Write-Host ("[{0}] STAGE={1} flags=0x{2:X}({3}) win_build={4} os_cr3=0x{5:X} hook_calls={6} last_status=0x{7:X}" -f `
            $Label, $stage, $flags, ($flagTxt -join ','), $build, $cr3, $calls, $lastst)
        return [pscustomobject]@{ stage = $stage; flags = $flags; build = $build; calls = $calls; lastst = $lastst }
    }
    Write-Host "[$Label] magic mismatch - unexpected data"
    return $null
}

function Write-Var([string]$name, [byte[]]$data) {
    $ok = [EfiVarBridge]::SetFirmwareEnvironmentVariableExW($name, $guid, $data, [uint32]$data.Length, [uint32]$attrs)
    $err = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    if ($ok) { Write-Host "[OK] $name write accepted (Win32=0)" }
    else {
        Write-Host "[FAIL] $name write Win32=$err"
        switch ($err) {
            1314 { Write-Host '   -> not elevated' }
            87   { Write-Host '   -> invalid parameter (name/GUID/attrs)' }
            5    { Write-Host '   -> access denied' }
            203  { Write-Host '   -> not found' }
        }
    }
    return $ok
}

function Try-Del([string]$name) {
    # best-effort delete (size 0 + same attributes = EFI delete)
    try { $null = [EfiVarBridge]::SetFirmwareEnvironmentVariableExW($name, $guid, $null, [uint32]0, [uint32]$attrs) } catch { }
}

function Read-VarBack([string]$name) {
    # returns byte[] or $null; prints one line
    $buf = New-Object byte[] 64
    $n = Read-EfiVar $name $buf
    if ($n -gt 0) {
        Write-Host "[OK] $name read-back: $n bytes: $(HexStr $buf $n)"
        return ,$buf[0..($n-1)]
    }
    Write-Host "[--] $name read-back: ABSENT (Win32=$LastErr)"
    return $null
}

# ============================================================
Write-Host '==== INFINITY trigger test v17 (the data-path proof: H..N) ===='
Write-Host ("[ENV] PowerShell $($PSVersionTable.PSVersion)  Windows build $([Environment]::OSVersion.Version.ToString())")

# [0] privilege
$rc = [EfiVarBridge]::EnablePriv('SeSystemEnvironmentPrivilege')
if (-not $rc) {
    Write-Host '[ABORT] SeSystemEnvironmentPrivilege failed - run PowerShell as Administrator.'
    __Finish 1
}
Write-Host '[OK] SeSystemEnvironmentPrivilege enabled (rc=0)'

# [1] cleanup stale probe variables from earlier runs (best-effort)
Try-Del 'INFPROBE'
Try-Del 'INFTRIGGER'
Try-Del 'InfinityReq'
Try-Del 'InfinityResp'
Try-Del 'InfinityData'
Try-Del 'INFCNT'
Start-Sleep -Milliseconds 200
Write-Host '[CLR] stale probe variables cleaned (best effort)'

# [2] baseline reads: A then B (no writes in between)
Write-Host ''
Write-Host '--- step A/B: baseline INFDIAG double read (read path via hook?) ---'
Write-Host '       v16: reads are answered LIVE from RAM by the hook (the'
Write-Host '       bridge is field-proven since v15), so B must be A+1 or'
Write-Host '       more if the read path works.'
$A = Read-Infdiag 'A'
Start-Sleep -Milliseconds 250
$B = Read-Infdiag 'B'
if ($null -eq $A -or $null -eq $B) {
    Write-Host '[ABORT] INFDIAG unreadable - is the RT driver (usb-d) the one that booted?'
    __Finish 1
}

# [3] neutral write probe: INFPROBE (not a driver name - pure raw NVRAM write)
Write-Host ''
Write-Host '--- step C: INFPROBE write (neutral name; raw NVRAM write path) ---'
$payload = New-Object byte[] 1
$payload[0] = 0x42
$null = Write-Var 'INFPROBE' $payload
Start-Sleep -Milliseconds 250
$C = Read-Infdiag 'C'
$probeBack = Read-VarBack 'INFPROBE'

# [4] driver trigger variable (first INFCNT increment)
Write-Host ''
Write-Host '--- step D: INFTRIGGER write (trigger flag 0x20 + INFCNT +1) ---'
$payload[0] = 0x42
$null = Write-Var 'INFTRIGGER' $payload
Start-Sleep -Milliseconds 250
$D = Read-Infdiag 'D'

# [5] the real PING (second INFCNT increment)
Write-Host ''
Write-Host '--- step E: InfinityReq PING (48 bytes, op=0xDEADBEEF) ---'
$req = New-Object byte[] 48
[BitConverter]::GetBytes([uint32]0x1337).CopyTo($req, 0)   # sequence (small literal: safe)
$opBytes = HexLe4 'DEADBEEF'
$opBytes.CopyTo($req, 4)                                    # op = PING
if ($req[0] -ne 0x37 -or $req[1] -ne 0x13 -or $req[4] -ne 0xEF -or $req[5] -ne 0xBE -or $req[6] -ne 0xAD -or $req[7] -ne 0xDE) {
    Write-Host '[ABORT] packet bytes wrong - refusing to send a broken ping.'
    __Finish 1
}
Write-Host "       req bytes[0..7]: $(HexStr $req 8)  (37 13 00 00 EF BE AD DE expected)"
$null = Write-Var 'InfinityReq' $req
Start-Sleep -Milliseconds 400
$E = Read-Infdiag 'E'   # live read right after the ping

Write-Host ''
Write-Host '--- step E2: reading InfinityResp (FULL BRIDGE check) ---'
$rbuf = New-Object byte[] 64
$rn = Read-EfiVar 'InfinityResp' $rbuf
$respAnswered = $false
$respTxt = 'ABSENT'
if ($rn -ge 32) {
    Write-Host "[OK] InfinityResp $rn bytes: $(HexStr $rbuf $rn)"
    $rseq  = U32 $rbuf 0
    $rstat = U32 $rbuf 4
    $rxfer = U64 $rbuf 8
    $raddr = U64 $rbuf 16
    # v16: decode the SlotStatus enum (SharedMemoryProtocol.h):
    # 0=Pending 1=Success 2=ErrGeneric 3=ErrTimeout 4=ErrAccess
    # 5=ErrInvalid 6=ErrNoBridge 7=ErrNotFound 8=ErrUnsupported.
    # status=1 IS Success - {seq echoed, status=1} is a PERFECT
    # PONG (the v15 verdict misread this as a failure).
    $statName = switch ($rstat) {
        0 {'Pending'}    1 {'Success'}      2 {'ErrGeneric'}
        3 {'ErrTimeout'} 4 {'ErrAccess'}    5 {'ErrInvalid'}
        6 {'ErrNoBridge'} 7 {'ErrNotFound'} 8 {'ErrUnsupported'}
        default { "Unknown($rstat)" }
    }
    Write-Host ("     sequence=0x{0:X}  status={1}({2})  bytes_transferred={3}  out_address=0x{4:X}" -f $rseq, $rstat, $statName, $rxfer, $raddr)
    if ($rseq -eq 0x1337 -and $rstat -eq 1) {
        $respAnswered = $true
        $respTxt = "ANSWERED seq=0x1337 status=1(Success) - PONG PERFECT"
    } else {
        $respTxt = "WRONG-CONTENT seq=0x$($rseq.ToString('X')) status=$rstat($statName)"
    }
} else {
    Write-Host "[--] InfinityResp ABSENT (Win32=$LastErr; 203 = not found)"
}

# [6] final state + read-backs
Write-Host ''
Write-Host '--- step F: final INFDIAG + InfinityReq read-back ---'
$F = Read-Infdiag 'F'
$reqBack = Read-VarBack 'InfinityReq'
$reqLanded = $false
if ($null -ne $reqBack -and $reqBack.Length -ge 8) {
    if ($reqBack[4] -eq 0xEF -and $reqBack[5] -eq 0xBE -and $reqBack[6] -eq 0xAD -and $reqBack[7] -eq 0xDE) {
        $reqLanded = $true
    }
}

# [7] INFCNT — live RAM-served write-path count
Write-Host ''
Write-Host '--- step G: INFCNT read (live RAM count: 0 = writes bypassed, 2 = both reached) ---'
$cntBack = Read-VarBack 'INFCNT'
$cntVal = -1
if ($null -ne $cntBack -and $cntBack.Length -ge 4) { $cntVal = U32 $cntBack 0 }

# ============================================================
# v17: THE DATA PATH - steps H..N (everything the real client
# Infinity.exe does for process memory, minus the emulator
# attach: payload transport, request/response round trips,
# kernel-target reads, a negative VA, INFCNT accounting).
# ============================================================
$KUSD_260 = 'FFFFF78000000260'                    # KUSER_SHARED_DATA + 0x260 (hex STRING - no PS literal trap)
$KUSD_308 = 'FFFFF78000000308'                    # KUSER_SHARED_DATA + 0x308 (v15/v16 field truth: reads 0)
$BAD_VA   = 'DEADBEEF00000000'                    # non-canonical VA (negative test)
$KP       = [Convert]::ToUInt32('FFFFFFFF', 16)    # KERNEL_TARGET_PID (the v17 driver addition)

function New-Req([uint32]$seq, [uint32]$op, [uint32]$pid, [uint32]$size, [string]$addrHex) {
    # 48-byte EfiVarReq: sequence, op, pid, data_size, address
    $r = New-Object byte[] 48
    [BitConverter]::GetBytes($seq).CopyTo($r, 0)
    [BitConverter]::GetBytes($op).CopyTo($r, 4)
    [BitConverter]::GetBytes($pid).CopyTo($r, 8)
    [BitConverter]::GetBytes($size).CopyTo($r, 12)
    if ($addrHex) { [BitConverter]::GetBytes([Convert]::ToUInt64($addrHex, 16)).CopyTo($r, 16) }
    return $r
}

function Send-Req([string]$Label, [byte[]]$req) {
    # write the request, read InfinityResp + InfinityData, decode, print
    $null = Write-Var 'InfinityReq' $req
    Start-Sleep -Milliseconds 400
    $rb = New-Object byte[] 64
    $rn = Read-EfiVar 'InfinityResp' $rb
    $seq = 0; $stat = 0; $xfer = 0; $statName = 'ABSENT'; $data = $null; $dataN = 0
    if ($rn -ge 32) {
        $seq  = U32 $rb 0
        $stat = U32 $rb 4
        $xfer = U64 $rb 8
        $statName = switch ($stat) {
            0 {'Pending'}    1 {'Success'}      2 {'ErrGeneric'}
            3 {'ErrTimeout'} 4 {'ErrAccess'}    5 {'ErrInvalid'}
            6 {'ErrNoBridge'} 7 {'ErrNotFound'} 8 {'ErrUnsupported'}
            default { "Unknown($stat)" }
        }
        Write-Host ("[{0}] resp: seq=0x{1:X}  status={2}({3})  bytes={4}" -f $Label, $seq, $stat, $statName, $xfer)
    } else {
        Write-Host "[$Label] resp: ABSENT (Win32=$LastErr)"
    }
    $db = New-Object byte[] 4096
    $dn = Read-EfiVar 'InfinityData' $db
    if ($dn -gt 0) {
        $data = ,$db[0..($dn-1)]
        $dataN = $dn
        $show = [Math]::Min($dn, 16)
        Write-Host ("[{0}] data: {1} bytes{2}: {3}" -f $Label, $dn,
            $(if ($dn -gt 16) {' (first 16)'} else {''}), (HexStr $db $show))
    } else {
        Write-Host "[$Label] data: none (0 bytes, Win32=$LastErr)"
    }
    return [pscustomobject]@{ seq = $seq; stat = $stat; statName = $statName;
                              xfer = $xfer; data = $data; dataN = $dataN }
}

# ---- step H: InfinityData write+read round trip (payload transport) ----
Write-Host ''
Write-Host '--- step H: InfinityData write+read round trip (the payload transport) ---'
$hPat = New-Object byte[] 32
for ($i = 0; $i -lt 32; $i++) { $hPat[$i] = [byte](($i * 7 + 11) % 251) }
[BitConverter]::GetBytes([uint32]0x1447).CopyTo($hPat, 0)
$null = Write-Var 'InfinityData' $hPat
Start-Sleep -Milliseconds 300
$hBack = Read-VarBack 'InfinityData'
$bufOk = $false
if ($null -ne $hBack -and $hBack.Length -eq 32) {
    $bufOk = $true
    for ($i = 0; $i -lt 32; $i++) { if ($hBack[$i] -ne $hPat[$i]) { $bufOk = $false; break } }
}
Write-Host ("     32-byte pattern echoed back byte-exact: {0}" -f $(if ($bufOk) {'YES - payload transport WORKS'} else {'NO'}))

# ---- step I: ReqOp_Attach attempt (expect ErrNotFound on the clean VM) ----
Write-Host ''
Write-Host '--- step I: ReqOp_Attach (op=7, pid=0 = any emulator process) ---'
$I = Send-Req 'I' (New-Req 0x1555 7 0 0 $null)
if ($I.stat -eq 7) {
    $attachTxt = 'ErrNotFound(7) - clean VM, no emulator running (correct decode)'
} elseif ($I.stat -eq 1) {
    $attachTxt = 'Success(1) - AN EMULATOR IS RUNNING (attach worked!)'
} else {
    $attachTxt = "status=$($I.stat)($($I.statName)) - see serial log"
}
Write-Host "     attach decode: $attachTxt"

# ---- step J: THE kernel read - KUSD+0x260 through the bridge ----
Write-Host ''
Write-Host '--- step J: kernel read KUSD+0x260 x4  (pid=FFFFFFFF = KERNEL target) ---'
$J = Send-Req 'J' (New-Req 0x1666 1 $KP 4 $KUSD_260)
$jBuild = -1
if ($J.stat -eq 1 -and $J.dataN -ge 4) { $jBuild = U32 $J.data 0 }
$osBuild2 = [Environment]::OSVersion.Version.Build
Write-Host ("     KUSD build dword VIA THE BRIDGE = {0}   (script-side = {1})" -f $jBuild, $osBuild2)
if ($jBuild -eq $osBuild2 -and $jBuild -gt 0) {
    Write-Host '     MATCH - the data path returned the live Windows build dword'
}

# ---- step K: kernel read KUSD+0x308 (field truth: 0) ----
Write-Host ''
Write-Host '--- step K: kernel read KUSD+0x308 x4  (v15/v16 field truth: 0) ---'
$K = Send-Req 'K' (New-Req 0x1777 1 $KP 4 $KUSD_308)
$kVal = -1
if ($K.stat -eq 1 -and $K.dataN -ge 4) { $kVal = U32 $K.data 0 }
Write-Host ("     KUSD+0x308 dword = {0}" -f $kVal)

# ---- step L: 8-byte chunk read (consistency with J) ----
Write-Host ''
Write-Host '--- step L: kernel read KUSD+0x260 x8  (chunk test; dword[0] must equal J) ---'
$L = Send-Req 'L' (New-Req 0x1888 1 $KP 8 $KUSD_260)
$l0 = -1; $l1 = -1
if ($L.stat -eq 1 -and $L.dataN -ge 8) { $l0 = U32 $L.data 0; $l1 = U32 $L.data 4 }
$chunkOk = ($l0 -eq $jBuild -and $jBuild -gt 0)
Write-Host ("     dword[0]={0} dword[1]=0x{1:X}  consistent with J: {2}" -f $l0, $l1,
    $(if ($chunkOk) {'YES'} else {'NO'}))

# ---- step M: NEGATIVE read - non-canonical VA (expect ErrAccess, no crash) ----
Write-Host ''
Write-Host '--- step M: kernel read NON-CANONICAL VA (expect ErrAccess(4), NO crash) ---'
$M = Send-Req 'M' (New-Req 0x1999 1 $KP 4 $BAD_VA)
$negOk = ($M.stat -eq 4)
Write-Host ("     negative-VA handling: {0}" -f $(if ($negOk) {
    'ErrAccess(4) cleanly - the page walk refused the bad address (safe by design)'
} else { "UNEXPECTED status=$($M.stat)($($M.statName)) - see serial log" }))

# ---- step N: final INFCNT (expect 8 = 2 baseline + 6 new protocol writes) ----
Write-Host ''
Write-Host '--- step N: final INFCNT read (live RAM count; expect 8 = 2 + H,I,J,K,L,M) ---'
$cnt2 = Read-VarBack 'INFCNT'
$cntFinal = -1
if ($null -ne $cnt2 -and $cnt2.Length -ge 4) { $cntFinal = U32 $cnt2 0 }

# ============================================================
# attribution (null-safe: -1 means that read failed)
function NCalls($x) { if ($null -ne $x) { return [int]$x.calls } else { return -1 } }
$cA = NCalls $A; $cB = NCalls $B; $cC = NCalls $C
$cD = NCalls $D; $cE = NCalls $E; $cF = NCalls $F
$fStage = -1; $fFlags = 0
if ($null -ne $F) { $fStage = $F.stage; $fFlags = $F.flags }

$readOk   = (($cB - $cA) -ge 1)          # read-only gap of >= 1
$trigSet  = ($fFlags -band 0x20) -ne 0     # (set BEFORE use - v13 ordering bug)
$writeOk  = ($cntVal -ge 1) -or ($trigSet)
$frozen   = ($cA -ge 0 -and $cA -eq $cB -and $cB -eq $cC -and $cC -eq $cF)
$probeFound = ($null -ne $probeBack)
$drvBuild = -1
if ($null -ne $A) { $drvBuild = [int]$A.build }
$osBuild  = [Environment]::OSVersion.Version.Build

# v16: under the v13+ RAM-consume design the driver consumes
# InfinityReq in RAM - the NVRAM read-back is EXPECTED to be ABSENT.
# Consumption evidence: INFCNT counted it (>= 2) and/or the PONG.
$reqConsumed = ($cntVal -ge 2) -or $respAnswered
$reqHow = if ($respAnswered) {'PONG proves it'}
          elseif ($cntVal -ge 2) {'INFCNT counted it'}
          else {'no evidence'}

Write-Host ''
Write-Host '==== SUMMARY (auto-saved to the output .txt) ===='
Write-Host ("hook_calls  A={0} B={1} C={2} D={3} E={4} F={5}" -f $cA, $cB, $cC, $cD, $cE, $cF)
Write-Host ("stage F={0}  flags F=0x{1:X}  trigger_seen(0x20)={2}" -f $fStage, $fFlags, $(if ($trigSet) {'SET'} else {'NOT-SET'}))
Write-Host ("win_build  driver-live={0}  script-side={1}   (equal = build detection works)" -f $drvBuild, $osBuild)
Write-Host ("INFCNT live RAM count (our-var writes that reached the hook) = {0}   (0 = bypassed, 2 = both)" -f $cntVal)
Write-Host ("[1] GetVariable path via hook : {0}" -f $(if ($readOk) {'PROVEN (hook_calls moves between reads)'} else {'BYPASSED (counts frozen - kernel reads NVRAM directly)'}))
Write-Host ("[2] SetVariable path via hook : {0}" -f $(if ($writeOk) {"PROVEN (INFCNT=$cntVal, flag 0x20)"} else {'BYPASSED (writes land in NVRAM but never touch the hook)'}))
Write-Host ("[3] INFPROBE landed in NVRAM  : {0}" -f $(if ($probeFound) {'YES (raw firmware write path works)'} else {'NO (write returned OK but variable absent!)'}))
Write-Host ("[4] InfinityReq consumed (RAM) : {0} ({1})" -f $(if ($reqConsumed) {'YES'} else {'NO'}), $reqHow)
Write-Host ("    NVRAM read-back: {0} - ABSENT is EXPECTED (v13+ consumes it in RAM)" -f $(if ($reqLanded) {'landed (UNEXPECTED)'} else {'absent'}))
Write-Host ("[5] InfinityResp PING         : {0}" -f $respTxt)
$kernTxt = if ($jBuild -eq $osBuild2 -and $jBuild -gt 0) {
    "PROVEN - build {0} read through the bridge == script-side (payload + status complete)" -f $jBuild
} else {
    "read returned {0} (expected {1}) - see serial [RD] lines" -f $jBuild, $osBuild2
}
Write-Host ("[6] InfinityData buffer round trip : {0}" -f $(if ($bufOk) {'BYTE-EXACT (payload transport works)'} else {'FAILED (pattern mismatch)'}))
Write-Host ("[7] ReqOp_Attach decode            : {0}" -f $attachTxt)
Write-Host ("[8] Kernel read KUSD+0x260 (J)     : {0}" -f $kernTxt)
Write-Host ("[9] Negative VA handling (M)       : {0}" -f $(if ($negOk) {'ErrAccess cleanly, no crash (safe by design)'} else {"UNEXPECTED status=$($M.stat)"}))
Write-Host ("    INFCNT final = {0}   (8 = the 2 baseline writes + all 6 new protocol writes reached the hook)" -f $cntFinal)

Write-Host ''
Write-Host 'VERDICT:'
$dataOk = ($bufOk -and ($jBuild -eq $osBuild2) -and ($jBuild -gt 0) -and $chunkOk)
if ($respAnswered -and $dataOk) {
    Write-Host '>>> DATA PATH PROVEN - FULL PROTOCOL COMPLETE <<<'
    Write-Host 'Windows -> InfinityReq(op,addr,size) -> OUR HOOK -> page-walk ->'
    Write-Host 'payload -> InfinityResp + InfinityData -> script. The EXACT'
    Write-Host 'transport Infinity.exe uses for process memory, proven live:'
    Write-Host ("build {0} was read out of KUSER_SHARED_DATA through the bridge." -f $jBuild)
    Write-Host 'v18 direction: attach to a real emulator process and read its'
    Write-Host 'memory through the bridge (production integration).'
} elseif ($respAnswered) {
    Write-Host '>>> FULL BRIDGE PROVEN (v16 result) <<< - but the data path'
    Write-Host 'did not return the expected dword. The serial log has the [RD]'
    Write-Host 'kern va / kern read ok lines - send output .txt + serial-phase-d.log.'
} elseif ($readOk -and $writeOk) {
    Write-Host 'Both paths reach the hook (reads + writes), but the response was not'
    Write-Host 'served - the request processing path failed inside the driver.'
    Write-Host 'Send the output .txt + serial-phase-d.log.'
} elseif ($readOk -and -not $writeOk) {
    Write-Host 'Reads reach the hook, writes BYPASS it (kernel writes NVRAM directly).'
    Write-Host 'v17 direction: shared-memory pool transport for Infinity.exe'
    Write-Host '(InfinityMem already in NVRAM + the 4MB pool).'
    Write-Host 'Send the output .txt + serial-phase-d.log.'
} elseif ($writeOk -and -not $readOk) {
    Write-Host 'Writes reach the hook (INFCNT moved), reads BYPASS it (counts frozen).'
    Write-Host 'v17 direction: serve responses through a REAL NVRAM variable the'
    Write-Host 'desktop can read without our hook.'
    Write-Host 'Send the output .txt + serial-phase-d.log.'
} else {
    Write-Host 'BOTH paths bypass our hooks (counts frozen AND INFCNT absent):'
    Write-Host 'desktop Windows variable transport is dead for our namespace.'
    Write-Host 'v17 direction: shared-memory pool transport for Infinity.exe'
    Write-Host '(the original ProjectMemory/SharedMemoryPool architecture).'
    Write-Host 'Send the output .txt + serial-phase-d.log.'
}
if ($frozen) {
    Write-Host ''
    Write-Host 'NOTE: hook_calls frozen across ALL steps. Since v15 this means'
    Write-Host 'the read path truly bypasses the hook. First rule out a stale'
    Write-Host 'driver: phase-d.bat must have said "package v17" and the serial'
    Write-Host 'log must show "memory.efi v17 RT".'
}
if ($drvBuild -le 0) {
    Write-Host ''
    Write-Host 'NOTE: driver-side win_build still 0 - the probe worked in v15'
    Write-Host '(KUSD+0x260 = 19045, offset settled), so a zero here means no'
    Write-Host 'INFDIAG read reached the hook this run. Send the output .txt +'
    Write-Host 'serial-phase-d.log.'
}
Write-Host '==== END v17 ===='
if ($__teeOk -and $__log) {
    Write-Host ''
    $fileOk = $false
    try {
        if ((Test-Path -LiteralPath $__log) -and ((Get-Item -LiteralPath $__log -ErrorAction Stop).Length -gt 0)) { $fileOk = $true }
    } catch { }
    if ($fileOk) {
        Write-Host "[LOG] output saved and VERIFIED: $__log"
    } else {
        Write-Host "[LOG] WARNING: transcript file missing or empty: $__log"
        Write-Host '[LOG] photo the screen as a backup.'
    }
    Write-Host '[LOG] HOW TO GET THE .TXT OUT of the VM (no photos needed):'
    Write-Host '[LOG]   1. on YOUR machine: put any file for the VM into the'
    Write-Host '[LOG]      transfer folder and double-click refresh-files.bat'
    Write-Host '[LOG]      - a USB stick appears inside Windows'
    Write-Host '[LOG]   2. inside Windows: copy the .txt onto that stick'
    Write-Host '[LOG]   3. on YOUR machine: run refresh-files.bat again - the'
    Write-Host '[LOG]      file lands in the transfer folder. Send that file.'
    __Finish 0
}
